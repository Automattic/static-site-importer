<?php
/**
 * Projects public diagnostic and error payloads for ability and receipt surfaces.
 *
 * @package StaticSiteImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Redacts materializer failures into bounded public diagnostics and error data. */
final class Static_Site_Importer_Public_Error_Projection {
	private const FAILURE_DIAGNOSTIC_MAX_ROWS    = 10;
	private const FAILURE_DIAGNOSTIC_MAX_BYTES   = 256;
	private const FAILURE_DIAGNOSTIC_SCAN_BUDGET = 10;

	/** @param array<int,mixed> $diagnostics @return array<int,array<string,mixed>> */
	public static function project_public_diagnostics( array $diagnostics ): array {
		$projected = array();
		$scanned   = 0;
		foreach ( $diagnostics as $diagnostic ) {
			if ( self::FAILURE_DIAGNOSTIC_SCAN_BUDGET <= $scanned++ ) {
				break;
			}
			if ( ! is_array( $diagnostic ) ) {
				continue;
			}
			$row = self::project_public_diagnostic( $diagnostic );
			if ( ! empty( $row ) ) {
				$projected[] = $row;
			}
			if ( self::FAILURE_DIAGNOSTIC_MAX_ROWS <= count( $projected ) ) {
				break;
			}
		}
		return $projected;
	}

	/** @param array<string,mixed> $data @return array<string,mixed> */
	public static function project_public_error_data( array $data ): array {
		$projected = array();
		foreach ( array( 'status', 'code', 'phase', 'declaration_id' ) as $field ) {
			if ( isset( $data[ $field ] ) ) {
				$value = self::project_public_token( $data[ $field ], 128 );
				if ( '' !== $value ) {
					$projected[ $field ] = $value;
				}
			}
		}
		$import_id = self::project_public_import_id( $data['import_id'] ?? null );
		if ( '' !== $import_id ) {
			$projected['import_id'] = $import_id;
		}
		foreach ( array( 'success', 'completed' ) as $field ) {
			if ( is_bool( $data[ $field ] ?? null ) ) {
				$projected[ $field ] = $data[ $field ];
			}
		}
		if ( is_bool( $data['resumable'] ?? null ) ) {
			$projected['resumable'] = $data['resumable'];
		}
		if ( is_array( $data['artifact_run'] ?? null ) ) {
			$artifact_run = self::project_public_artifact_run( $data['artifact_run'] );
			if ( ! empty( $artifact_run ) ) {
				$projected['artifact_run'] = $artifact_run;
			}
		}
		if ( is_array( $data['diagnostics'] ?? null ) ) {
			$projected['diagnostics'] = self::project_public_diagnostics( $data['diagnostics'] );
		}
		if ( is_array( $data['dependency'] ?? null ) ) {
			$dependency = array();
			foreach ( array( 'slug', 'plugin_file', 'source', 'status' ) as $field ) {
				$value = self::project_public_token( $data['dependency'][ $field ] ?? null, 128 );
				if ( '' !== $value ) {
					$dependency[ $field ] = $value;
				}
			}
			if ( is_array( $data['dependency']['error'] ?? null ) ) {
				$error = array();
				foreach ( array( 'code', 'message' ) as $field ) {
					$value = self::project_public_token( $data['dependency']['error'][ $field ] ?? null, 256 );
					if ( '' !== $value ) {
						$error[ $field ] = $value;
					}
				}
				if ( ! empty( $error ) ) {
					$dependency['error'] = $error;
				}
			}
			if ( ! empty( $dependency ) ) {
				$projected['dependency'] = $dependency;
			}
		}
		if ( is_array( $data['import_validation_result']['diagnostics'] ?? null ) ) {
			$projected['import_validation_result'] = array(
				'diagnostics' => self::project_public_diagnostics( $data['import_validation_result']['diagnostics'] ),
			);
		}
		if ( is_array( $data['import_report_summary'] ?? null ) ) {
			$summary = self::project_public_error_summary( $data['import_report_summary'] );
			if ( ! empty( $summary ) ) {
				$projected['import_report_summary'] = $summary;
			}
		}
		if ( is_array( $data['quality'] ?? null ) ) {
			$quality = self::project_public_error_summary( $data['quality'] );
			if ( ! empty( $quality ) ) {
				$projected['quality'] = $quality;
			}
		}
		return $projected;
	}

	/** @param array<int,array<string,mixed>> $diagnostics */
	public static function project_public_error_message( string $code, array $diagnostics = array() ): string {
		$source_path = isset( $diagnostics[0]['source_path'] ) ? (string) $diagnostics[0]['source_path'] : '';
		if ( '' !== $source_path ) {
			return 'Materialization failed for ' . $source_path . '.';
		}
		return 'Materialization failed (' . self::project_public_token( $code, 128, 'materialization_failed' ) . ').';
	}

	/** @param array<string,mixed> $artifact_run @return array<string,mixed> */
	private static function project_public_artifact_run( array $artifact_run ): array {
		$projected = array();
		foreach ( array( 'state', 'phase' ) as $field ) {
			if ( isset( $artifact_run[ $field ] ) ) {
				$value = self::project_public_token( $artifact_run[ $field ], 128 );
				if ( '' !== $value ) {
					$projected[ $field ] = $value;
				}
			}
		}
		$artifact_identity = self::project_public_hash( $artifact_run['artifact_identity'] ?? null );
		if ( '' !== $artifact_identity ) {
			$projected['artifact_identity'] = $artifact_identity;
		}
		if ( is_array( $artifact_run['progress'] ?? null ) ) {
			$progress = array();
			foreach ( array( 'page_count', 'prepared_count', 'receipt_count', 'remaining' ) as $field ) {
				if ( is_numeric( $artifact_run['progress'][ $field ] ?? null ) ) {
					$progress[ $field ] = max( 0, (int) $artifact_run['progress'][ $field ] );
				}
			}
			if ( ! empty( $progress ) ) {
				$projected['progress'] = $progress;
			}
		}
		if ( is_array( $artifact_run['work'] ?? null ) ) {
			$work = array();
			foreach ( array( 'content_policy_applications', 'client_script_policy_applications', 'payloads_retained', 'shared_prepares', 'page_prepare_passes', 'page_plans_prepared', 'compile_batches', 'pages_compiled', 'compositions', 'materialization_claims', 'materialization_attempts', 'materializations', 'lifecycle_preparation_claims', 'lifecycle_preparation_attempts', 'lifecycle_preparations' ) as $field ) {
				if ( is_numeric( $artifact_run['work'][ $field ] ?? null ) ) {
					$work[ $field ] = max( 0, (int) $artifact_run['work'][ $field ] );
				}
			}
			if ( ! empty( $work ) ) {
				$projected['work'] = $work;
			}
		}
		if ( is_array( $artifact_run['failures'] ?? null ) ) {
			$failures = array();
			foreach ( array_slice( $artifact_run['failures'], 0, self::FAILURE_DIAGNOSTIC_MAX_ROWS ) as $failure ) {
				if ( ! is_array( $failure ) ) {
					continue;
				}
				$row = array();
				foreach ( array( 'phase', 'exception_class' ) as $field ) {
					$value = self::project_public_token( $failure[ $field ] ?? null, 128 );
					if ( '' !== $value ) {
						$row[ $field ] = $value;
					}
				}
				$artifact_identity = self::project_public_hash( $failure['artifact_identity'] ?? null );
				if ( '' !== $artifact_identity ) {
					$row['artifact_identity'] = $artifact_identity;
				}
				if ( ! empty( $row ) ) {
					$failures[] = $row;
				}
			}
			if ( ! empty( $failures ) ) {
				$projected['failures'] = $failures;
			}
		}
		return $projected;
	}

	/** @param array<string,mixed> $summary @return array<string,mixed> */
	private static function project_public_error_summary( array $summary ): array {
		$projected = array();
		foreach ( array( 'status' ) as $field ) {
			if ( isset( $summary[ $field ] ) ) {
				$value = self::project_public_token( $summary[ $field ], 128 );
				if ( '' !== $value ) {
					$projected[ $field ] = $value;
				}
			}
		}
		foreach ( array( 'quality_pass', 'fail_import', 'pass' ) as $field ) {
			if ( is_bool( $summary[ $field ] ?? null ) ) {
				$projected[ $field ] = $summary[ $field ];
			}
		}
		foreach ( array( 'failure_reasons' ) as $field ) {
			if ( ! is_array( $summary[ $field ] ?? null ) ) {
				continue;
			}
			$values  = array();
			$scanned = 0;
			foreach ( $summary[ $field ] as $value ) {
				if ( self::FAILURE_DIAGNOSTIC_SCAN_BUDGET <= $scanned++ ) {
					break;
				}
				$value = self::project_public_token( $value, 128 );
				if ( '' !== $value ) {
					$values[] = $value;
				}
			}
			if ( ! empty( $values ) ) {
				$projected[ $field ] = $values;
			}
		}
		foreach ( array( 'core_html_block_count', 'fallback_count', 'diagnostic_count', 'loss_count' ) as $field ) {
			if ( is_numeric( $summary[ $field ] ?? null ) ) {
				$projected[ $field ] = max( 0, (int) $summary[ $field ] );
			}
		}
		return $projected;
	}

	/** @param array<string,mixed> $diagnostic @return array<string,mixed> */
	private static function project_public_diagnostic( array $diagnostic ): array {
		$row = array();
		foreach ( array( 'code', 'type', 'kind', 'severity', 'declaration_id', 'entity_type', 'provider', 'reason_code', 'provider_availability_reason' ) as $field ) {
			if ( isset( $diagnostic[ $field ] ) ) {
				$row[ $field ] = self::project_public_token( $diagnostic[ $field ], 128 );
			}
		}
		if ( isset( $diagnostic['provider_available'] ) && is_bool( $diagnostic['provider_available'] ) ) {
			$row['provider_available'] = $diagnostic['provider_available'];
		}
		if ( isset( $diagnostic['loss_count'] ) && is_numeric( $diagnostic['loss_count'] ) ) {
			$row['loss_count'] = max( 0, (int) $diagnostic['loss_count'] );
		}
		if ( isset( $diagnostic['source_path'] ) ) {
			$source_path = self::project_public_source_path( $diagnostic['source_path'] );
			if ( '' !== $source_path ) {
				$row['source_path'] = $source_path;
			}
		}
		if ( isset( $diagnostic['selector'] ) ) {
			$selector = self::project_public_selector( $diagnostic['selector'] );
			if ( '' !== $selector ) {
				$row['selector'] = $selector;
			}
		}
		if ( isset( $diagnostic['reconciliation_identity'] ) && is_string( $diagnostic['reconciliation_identity'] ) && 1 === preg_match( '/^[a-f0-9]{64}$/', $diagnostic['reconciliation_identity'] ) ) {
			$row['reconciliation_identity'] = $diagnostic['reconciliation_identity'];
		}
		if ( is_array( $diagnostic['binding_reconciliation_identities'] ?? null ) ) {
			$identities = array();
			$scanned    = 0;
			foreach ( $diagnostic['binding_reconciliation_identities'] as $identity ) {
				if ( self::FAILURE_DIAGNOSTIC_SCAN_BUDGET <= $scanned++ ) {
					break;
				}
				if ( is_string( $identity ) && 1 === preg_match( '/^[a-f0-9]{64}$/', $identity ) ) {
					$identities[] = $identity;
				}
			}
			if ( ! empty( $identities ) ) {
				$row['binding_reconciliation_identities'] = $identities;
			}
		}
		if ( empty( $row ) ) {
			return array();
		}
		if ( empty( $row['code'] ) ) {
			$row['code'] = 'materialization_failed';
		}
		$code           = is_string( $row['code'] ) ? $row['code'] : 'materialization_failed';
		$row['code']    = $code;
		$row['message'] = self::project_public_error_message( $code, array( $row ) );
		return $row;
	}

	private static function project_public_source_path( $value ): string {
		$value = self::project_public_text( $value );
		if ( '' === $value || str_contains( $value, '\\' ) || str_contains( $value, '..' ) || preg_match( '/^[A-Za-z]:|[?#:]/', $value ) || preg_match( '#^(?:https?|file)://#i', $value ) ) {
			return '';
		}
		if ( str_starts_with( $value, '$' ) ) {
			return 1 === preg_match( '/^\$[.\[\]A-Za-z0-9_-]*$/', $value ) ? $value : '';
		}
		if ( str_starts_with( $value, '/' ) ) {
			return '';
		}
		return 1 === preg_match( '#^[\pL\pN][\pL\pN_.\-/]*$#u', $value ) ? $value : '';
	}

	private static function project_public_selector( $value ): string {
		$value = self::project_public_text( $value );
		return 1 === preg_match( '/^[A-Za-z0-9_.#\-\[\]=\s>+~,*]+$/', $value ) ? $value : '';
	}

	private static function project_public_token( $value, int $bytes, string $fallback = '' ): string {
		$value = self::project_public_text( $value, $bytes );
		return 1 === preg_match( '/^[A-Za-z][A-Za-z0-9_-]*$/', $value ) ? $value : $fallback;
	}

	private static function project_public_hash( $value ): string {
		$value = self::project_public_text( $value, 64 );
		return 1 === preg_match( '/^[a-f0-9]{64}$/', $value ) ? $value : '';
	}

	private static function project_public_import_id( $value ): string {
		$token = self::project_public_token( $value, 128 );
		return '' !== $token ? $token : self::project_public_hash( $value );
	}

	private static function project_public_text( $value, int $bytes = self::FAILURE_DIAGNOSTIC_MAX_BYTES ): string {
		if ( ! is_scalar( $value ) ) {
			return '';
		}
		$value = trim( (string) $value );
		if ( '' === $value || preg_match( '/(?:password|secret|token|authorization|api[_-]?key|cookie|bearer)\s*[:=]?/i', $value ) || preg_match( '#(?:https?|file)://#i', $value ) || ! preg_match( '//u', $value ) ) {
			return '';
		}
		if ( strlen( $value ) <= $bytes ) {
			return $value;
		}
		preg_match_all( '/./us', $value, $characters );
		$text = '';
		foreach ( $characters[0] as $character ) {
			if ( $bytes < strlen( $text . $character ) ) {
				break;
			}
			$text .= $character;
		}
		return $text;
	}
}
