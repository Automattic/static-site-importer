<?php
/**
 * Generated-theme block-document analysis and report serialization.
 *
 * Analyzes generated block-theme documents (templates/, parts/, patterns/) for
 * server-visible block-quality issues and records actionable diagnostics into the
 * import conversion report. Extracted from Static_Site_Importer_Theme_Generator as a
 * behavior-preserving decomposition slice; the generator delegates to this class and
 * passes its conversion report object.
 *
 * @package StaticSiteImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Static_Site_Importer_Import_Report' ) ) {
	require_once __DIR__ . '/class-static-site-importer-import-report.php';
}
if ( ! class_exists( 'Static_Site_Importer_Form_Fallback_Contract' ) ) {
	require_once __DIR__ . '/class-static-site-importer-form-fallback-contract.php';
}

/**
 * Analyzes generated block documents and routes block-quality diagnostics into the report.
 */
class Static_Site_Importer_Block_Document_Reporter {

	/**
	 * Analyze final page post_content and replace any pre-materialization counts.
	 *
	 * @param array<int,array<string,mixed>>       $documents Materialized documents with path and content.
	 * @param Static_Site_Importer_Import_Report $report    Conversion report (mutated by reference).
	 * @return void
	 */
	public static function analyze_materialized_block_documents( array $documents, Static_Site_Importer_Import_Report $report ): void {
		$documents = array_values( array_filter( $documents, static fn( $document ): bool => is_string( $document['path'] ?? null ) && is_string( $document['content'] ?? null ) && '' !== trim( $document['content'] ) ) );
		if ( empty( $documents ) ) {
			return;
		}
		self::reset_block_document_quality( $report );
		$report->set_in_section( 'materialized_content', 'block_documents', array() );

		foreach ( $documents as $document ) {
			$analysis = self::analyze_generated_block_document( $document['path'], $document['content'], $report );
			$report->append_to_section( 'materialized_content', 'block_documents', $analysis );
		}
	}

	/**
	 * Analyze generated block documents and record diagnostics into the conversion report.
	 *
	 * @param array<string,string> $writes    Generated theme writes keyed by absolute path.
	 * @param string               $theme_dir Generated theme directory.
	 * @param Static_Site_Importer_Import_Report  $report    Conversion report (mutated by reference).
	 * @return void
	 */
	public static function analyze_generated_theme_block_documents( array $writes, string $theme_dir, Static_Site_Importer_Import_Report $report ): void {
		foreach ( $writes as $path => $content ) {
			$relative_path = ltrim( str_replace( trailingslashit( $theme_dir ), '', $path ), '/' );
			if ( ! self::is_generated_block_document_path( $relative_path ) ) {
				continue;
			}

			$block_markup = self::generated_block_document_markup( $relative_path, $content );
			$analysis     = self::analyze_generated_block_document( $relative_path, $block_markup, $report );
			$report->append_to_section( 'generated_theme', 'block_documents', $analysis );
		}
	}

	/**
	 * Clear generated-document analysis before analyzing mutated final documents.
	 *
	 * @param Static_Site_Importer_Import_Report $report Conversion report (mutated by reference).
	 * @return void
	 */
	public static function reset_generated_block_document_analysis( Static_Site_Importer_Import_Report $report ): void {
		self::reset_block_document_quality( $report );
		$report->set_in_section( 'materialized_content', 'block_documents', array() );
		$report->set_in_section( 'generated_theme', 'block_documents', array() );
	}

	private static function reset_block_document_quality( Static_Site_Importer_Import_Report $report ): void {
		$report->merge_quality(
			array(
				'block_count'                  => 0,
				'core_html_block_count'        => 0,
				'freeform_block_count'         => 0,
				'invalid_block_count'          => 0,
				'invalid_block_document_count' => 0,
				'image_missing_source_count'   => 0,
			)
		);
		$report->filter_diagnostics(
			static function ( $diagnostic ): bool {
				return ! is_array( $diagnostic ) || 'generated_theme_block_analysis' !== (string) ( $diagnostic['stage'] ?? '' );
			}
		);
	}

	/**
	 * Determine whether a generated file should contain block markup.
	 *
	 * @param string $relative_path Theme-relative path.
	 * @return bool
	 */
	private static function is_generated_block_document_path( string $relative_path ): bool {
		return str_starts_with( $relative_path, 'templates/' ) || str_starts_with( $relative_path, 'parts/' ) || str_starts_with( $relative_path, 'patterns/' );
	}

	/**
	 * Extract block markup from a generated block document.
	 *
	 * @param string $relative_path Theme-relative path.
	 * @param string $content       Generated file content.
	 * @return string
	 */
	private static function generated_block_document_markup( string $relative_path, string $content ): string {
		if ( str_starts_with( $relative_path, 'patterns/' ) ) {
			$parts = explode( '?>', $content, 2 );
			return trim( 2 === count( $parts ) ? $parts[1] : $content );
		}

		return trim( $content );
	}

	/**
	 * Analyze one generated block document for server-visible quality issues.
	 *
	 * Public so the theme generator can reuse it for materialized post_content analysis.
	 *
	 * @param string              $relative_path Theme-relative path.
	 * @param string              $block_markup  Block markup.
	 * @param Static_Site_Importer_Import_Report $report        Conversion report (mutated by reference).
	 * @return array<string,mixed>
	 */
	public static function analyze_generated_block_document( string $relative_path, string $block_markup, Static_Site_Importer_Import_Report $report ): array {
		$validation_method = function_exists( 'parse_blocks' ) && function_exists( 'serialize_blocks' ) ? 'wordpress_parse_blocks_serialize_blocks' : 'unavailable';
		if ( 'unavailable' === $validation_method ) {
			$counts = self::serialized_block_counts( $block_markup );
			$report->increment_quality( 'block_count', $counts['block_count'] );
			$report->increment_quality( 'core_html_block_count', $counts['core_html_block_count'] );
			$report->increment_quality( 'freeform_block_count', $counts['freeform_block_count'] );
			return array(
				'path'                   => $relative_path,
				'block_count'            => $counts['block_count'],
				'core_html_block_count'  => $counts['core_html_block_count'],
				'freeform_block_count'   => $counts['freeform_block_count'],
				'invalid_block_count'    => 0,
				'serialization_mismatch' => false,
				'validation_method'      => $validation_method,
				'validation_available'   => false,
			);
		}

		$blocks          = parse_blocks( $block_markup );
		$block_count     = 0;
		$core_html_count = 0;
		$freeform_count  = 0;
		$invalid_count   = 0;
		$invalid_blocks  = array();

		/** @var array<int, array<string, mixed>> $analyzed_blocks */
		$analyzed_blocks = $blocks;
		self::analyze_generated_block_list( $analyzed_blocks, $block_count, $core_html_count, $freeform_count, $invalid_count, $invalid_blocks, $report, $relative_path );
		if ( 0 === $block_count ) {
			$serialized_counts = self::serialized_block_counts( $block_markup );
			$block_count       = $serialized_counts['block_count'];
			$core_html_count   = $serialized_counts['core_html_block_count'];
			$freeform_count    = $serialized_counts['freeform_block_count'];
		}

		$serialized             = serialize_blocks( $blocks );
		$serialization_mismatch = self::block_documents_differ_for_report( $block_markup, $serialized );
		$first_differing_token  = array();
		if ( $serialization_mismatch ) {
			++$invalid_count;
			$first_differing_token = self::first_differing_block_document_token( $block_markup, $serialized );
		}

		$report->increment_quality( 'block_count', $block_count );
		$report->increment_quality( 'core_html_block_count', $core_html_count );
		$report->increment_quality( 'freeform_block_count', $freeform_count );
		$report->increment_quality( 'invalid_block_count', $invalid_count );
		self::report_sourceless_images( $block_markup, $relative_path, $report );
		if ( $invalid_count > 0 ) {
			$report->increment_quality( 'invalid_block_document_count' );
			$first_invalid_block = $invalid_blocks[0] ?? self::first_parsed_block_summary( $analyzed_blocks );
			$validation_message  = $serialization_mismatch ? 'Serialized block document differs from generated block markup.' : 'Generated block document contains parser-exposed invalid block markup.';
			$diagnostic          = array(
				'type'                      => 'invalid_block_document',
				'stage'                     => 'generated_theme_block_analysis',
				'source'                    => $relative_path,
				'block_count'               => $block_count,
				'core_html_block_count'     => $core_html_count,
				'freeform_block_count'      => $freeform_count,
				'invalid_block_count'       => $invalid_count,
				'serialization_mismatch'    => $serialization_mismatch,
				'validation_message'        => $validation_message,
				'parser_validation_message' => $validation_message,
				'original_excerpt'          => Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( $block_markup ),
				'serialized_excerpt'        => Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( $serialized ),
			);
			if ( ! empty( $first_invalid_block ) ) {
				$diagnostic['block_name']     = $first_invalid_block['block_name'];
				$diagnostic['block_path']     = $first_invalid_block['block_path'];
				$diagnostic['attribute_path'] = $first_invalid_block['attribute_path'];
				$diagnostic['invalid_blocks'] = $invalid_blocks;
			}
			if ( ! empty( $first_differing_token ) ) {
				$diagnostic['first_differing_token'] = $first_differing_token;
			}

			$report->append_diagnostic( $diagnostic );
		}

		return array(
			'path'                   => $relative_path,
			'block_count'            => $block_count,
			'core_html_block_count'  => $core_html_count,
			'freeform_block_count'   => $freeform_count,
			'invalid_block_count'    => $invalid_count,
			'serialization_mismatch' => $serialization_mismatch,
			'validation_method'      => $validation_method,
			'validation_available'   => true,
		);
	}

	/**
	 * Report images a document emits without a usable source.
	 *
	 * A source never ships an image element that resolves to nothing, so one in
	 * generated markup is invalid output: it requests nothing, renders as a
	 * broken or zero-sized box, and is invisible to block validation because the
	 * block itself still parses.
	 *
	 * @param string                             $block_markup  Generated block markup.
	 * @param string                             $relative_path Document path for the diagnostic.
	 * @param Static_Site_Importer_Import_Report $report        Report being built.
	 */
	private static function report_sourceless_images( string $block_markup, string $relative_path, Static_Site_Importer_Import_Report $report ): void {
		if ( ! preg_match_all( '/<img\b[^>]*>/i', $block_markup, $matches ) ) {
			return;
		}
		$sourceless = array();
		foreach ( $matches[0] as $tag ) {
			if ( preg_match( '/\bsrc(?:set)?\s*=\s*(["\'])\s*\S[^"\']*\1/i', $tag )
				|| preg_match( '/\bsrc(?:set)?\s*=\s*[^\s>"\']+/i', $tag ) ) {
				continue;
			}
			$sourceless[] = $tag;
		}
		if ( array() === $sourceless ) {
			return;
		}

		$report->increment_quality( 'image_missing_source_count', count( $sourceless ) );
		$report->append_diagnostic(
			array(
				'type'               => 'image_missing_source',
				'stage'              => 'generated_theme_block_analysis',
				'source'             => $relative_path,
				'count'              => count( $sourceless ),
				'validation_message' => 'Generated markup emits an image element without a source.',
				'original_excerpt'   => Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( $sourceless[0] ),
			)
		);
	}

	/** @return array{block_count:int,core_html_block_count:int,freeform_block_count:int} */
	private static function serialized_block_counts( string $content ): array {
		$counts = array(
			'block_count'           => 0,
			'core_html_block_count' => 0,
			'freeform_block_count'  => 0,
		);
		if ( ! preg_match_all( '/<!--\s+wp:([a-z][a-z0-9-]*(?:\/[a-z][a-z0-9-]*)?)/i', $content, $matches ) ) {
			return $counts;
		}
		foreach ( $matches[1] as $name ) {
			$name = strtolower( (string) $name );
			++$counts['block_count'];
			if ( 'html' === $name || 'core/html' === $name ) {
				++$counts['core_html_block_count'];
			} elseif ( 'freeform' === $name || 'core/freeform' === $name ) {
				++$counts['freeform_block_count'];
			}
		}
		return $counts;
	}

	/**
	 * Walk parsed blocks for generated-theme quality metrics.
	 *
	 * @param array<int,array<string,mixed>> $blocks          Parsed blocks.
	 * @param int                            $block_count     Total named block count.
	 * @param int                            $core_html_count HTML block count.
	 * @param int                            $freeform_count  Freeform block count.
	 * @param int                            $invalid_count   Invalid block count.
	 * @param array<int,mixed>               $invalid_blocks  Collected invalid block summaries.
	 * @param Static_Site_Importer_Import_Report            $report          Conversion report (mutated by reference).
	 * @param string                         $source          Theme-relative source document path.
	 * @param array<int,int>                 $path            Parsed block path.
	 * @return void
	 */
	private static function analyze_generated_block_list( array $blocks, int &$block_count, int &$core_html_count, int &$freeform_count, int &$invalid_count, array &$invalid_blocks, Static_Site_Importer_Import_Report $report, string $source = '', array $path = array() ): void {
		foreach ( $blocks as $index => $block ) {
			$block_path = array_merge( $path, array( $index ) );
			$name       = isset( $block['blockName'] ) ? $block['blockName'] : null;
			if ( is_string( $name ) && '' !== $name ) {
				++$block_count;
				if ( 'core/html' === $name ) {
					++$core_html_count;
					self::record_generated_core_html_block( $source, $block_path, $block, $report );
				}
				if ( 'core/freeform' === $name ) {
					++$freeform_count;
					self::record_generated_freeform_block( $source, $block_path, $block, false, $report );
				}
			} elseif ( '' !== trim( isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ? $block['innerHTML'] : '' ) ) {
				++$freeform_count;
				++$invalid_count;
				$invalid_blocks[] = array(
					'block_name'     => 'unparsed_html',
					'block_path'     => implode( '.', $block_path ),
					'attribute_path' => 'innerHTML',
					'reason'         => 'parser_exposed_unparsed_html',
					'html_excerpt'   => Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( (string) $block['innerHTML'] ),
				);
				self::record_generated_freeform_block( $source, $block_path, $block, true, $report );
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::analyze_generated_block_list( $block['innerBlocks'], $block_count, $core_html_count, $freeform_count, $invalid_count, $invalid_blocks, $report, $source, $block_path );
			}
		}
	}

	/**
	 * Return the first named parsed block as context for document-level mismatches.
	 *
	 * @param array<int,array<string,mixed>> $blocks Parsed blocks.
	 * @param array<int,int>                 $path   Current block path.
	 * @return array<string,string>
	 */
	private static function first_parsed_block_summary( array $blocks, array $path = array() ): array {
		foreach ( $blocks as $index => $block ) {
			$block_path = array_merge( $path, array( $index ) );
			$name       = isset( $block['blockName'] ) && is_string( $block['blockName'] ) && '' !== $block['blockName'] ? $block['blockName'] : '';
			if ( '' !== $name ) {
				return array(
					'block_name'     => $name,
					'block_path'     => implode( '.', $block_path ),
					'attribute_path' => 'document',
				);
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$summary = self::first_parsed_block_summary( $block['innerBlocks'], $block_path );
				if ( ! empty( $summary ) ) {
					return $summary;
				}
			}
		}

		return array();
	}

	/**
	 * Record an actionable generated core/html block diagnostic.
	 *
	 * @param string              $source Theme-relative source document path.
	 * @param array<int,int>      $path   Parsed block path.
	 * @param array<string,mixed> $block  Parsed block.
	 * @param Static_Site_Importer_Import_Report $report Conversion report (mutated by reference).
	 * @return void
	 */
	private static function record_generated_core_html_block( string $source, array $path, array $block, Static_Site_Importer_Import_Report $report ): void {
		$html = '';
		if ( isset( $block['attrs']['content'] ) && is_string( $block['attrs']['content'] ) ) {
			$html = $block['attrs']['content'];
		} elseif ( isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ) {
			$html = $block['innerHTML'];
		}

		$diagnostic = Static_Site_Importer_Report_Diagnostics::fallback_diagnostic_entry(
			'core_html_block',
			$source,
			$html,
			array(
				'reason' => 'generated_document_contains_core_html',
				'stage'  => 'generated_theme_block_analysis',
				'path'   => implode( '.', $path ),
			),
			$block
		);
		if ( 'form' === strtolower( (string) ( $diagnostic['tag_name'] ?? '' ) ) ) {
			$manifest               = Static_Site_Importer_Form_Fallback_Contract::manifest_from_metadata( $diagnostic );
			$diagnostic['form']     = $manifest['form'];
			$diagnostic['controls'] = $manifest['controls'];
		}
		$report->append_diagnostic( $diagnostic );
	}

	/**
	 * Record an actionable generated freeform block diagnostic.
	 *
	 * @param string              $source     Theme-relative source document path.
	 * @param array<int,int>      $path       Parsed block path.
	 * @param array<string,mixed> $block      Parsed block.
	 * @param bool                $malformed  Whether the block parser exposed raw HTML without a block name.
	 * @param Static_Site_Importer_Import_Report $report     Conversion report (mutated by reference).
	 * @return void
	 */
	private static function record_generated_freeform_block( string $source, array $path, array $block, bool $malformed, Static_Site_Importer_Import_Report $report ): void {
		$html = '';
		if ( isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ) {
			$html = $block['innerHTML'];
		}

		$emitted = '';
		if ( ! $malformed && function_exists( 'serialize_blocks' ) ) {
			// @phpstan-ignore-next-line argument.type -- Parsed block shape comes from WordPress parse_blocks().
			$emitted = serialize_blocks( array( $block ) );
		}
		if ( '' === trim( $emitted ) ) {
			$emitted = $html;
		}

		$entry                          = Static_Site_Importer_Report_Diagnostics::fallback_diagnostic_entry(
			'freeform_block',
			$source,
			$html,
			array(
				'reason' => $malformed ? 'generated_document_contains_malformed_freeform_html' : 'generated_document_contains_core_freeform',
				'stage'  => 'generated_theme_block_analysis',
				'path'   => implode( '.', $path ),
			),
			$block
		);
		$entry['emitted_block_preview'] = Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( $emitted );
		$entry['malformed']             = $malformed;

		$report->append_diagnostic( $entry );
		$report->append_to_section( 'generated_theme', 'freeform_blocks', $entry );
	}

	/**
	 * Normalize generated markup enough to avoid formatting-only report noise.
	 *
	 * @param string $markup Block document markup.
	 * @return string
	 */
	private static function normalize_block_document_for_report( string $markup ): string {
		$markup = str_replace( array( "\r\n", "\r" ), "\n", trim( $markup ) );
		$markup = preg_replace( '/>\s+</', '><', $markup );
		$markup = preg_replace( '/\s+/', ' ', is_string( $markup ) ? $markup : '' );

		return is_string( $markup ) ? trim( $markup ) : '';
	}

	/**
	 * Determine whether two block documents differ semantically for report purposes.
	 *
	 * @param string $original   Original generated markup.
	 * @param string $serialized WordPress-serialized markup.
	 * @return bool
	 */
	private static function block_documents_differ_for_report( string $original, string $serialized ): bool {
		if ( self::normalize_block_document_for_report( $original ) === self::normalize_block_document_for_report( $serialized ) ) {
			return false;
		}

		$original_blocks   = self::canonical_parsed_block_document_for_report( $original );
		$serialized_blocks = self::canonical_parsed_block_document_for_report( $serialized );
		if ( array() !== $original_blocks || array() !== $serialized_blocks ) {
			return $original_blocks !== $serialized_blocks;
		}

		return true;
	}

	/**
	 * Parse a block document into a canonical shape for semantic report comparison.
	 *
	 * @param string $markup Block document markup.
	 * @return array<int,mixed>
	 */
	private static function canonical_parsed_block_document_for_report( string $markup ): array {
		if ( ! function_exists( 'parse_blocks' ) ) {
			return array();
		}

		$blocks = parse_blocks( $markup );
		return self::canonicalize_parsed_block_values_for_report( $blocks );
	}

	/**
	 * Normalize parsed block values so harmless serializer escaping does not fail reports.
	 *
	 * @param mixed $value Parsed block value.
	 * @return mixed
	 */
	private static function canonicalize_parsed_block_values_for_report( mixed $value ): mixed {
		if ( is_string( $value ) ) {
			$decoded = json_decode( '"' . str_replace( '"', '\\"', $value ) . '"' );
			return is_string( $decoded ) ? $decoded : $value;
		}
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$normalized = array();
		foreach ( $value as $key => $item ) {
			$normalized[ $key ] = self::canonicalize_parsed_block_values_for_report( $item );
		}

		return $normalized;
	}

	/**
	 * Report the first token that differs between generated and serialized block documents.
	 *
	 * @param string $original   Original generated markup.
	 * @param string $serialized WordPress-serialized markup.
	 * @return array<string,mixed>
	 */
	private static function first_differing_block_document_token( string $original, string $serialized ): array {
		$original_tokens   = preg_split( '/(<!--\s*\/?wp:[^>]+-->|<[^>]+>|\s+)/', self::normalize_block_document_for_report( $original ), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$serialized_tokens = preg_split( '/(<!--\s*\/?wp:[^>]+-->|<[^>]+>|\s+)/', self::normalize_block_document_for_report( $serialized ), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$original_tokens   = false !== $original_tokens ? $original_tokens : array();
		$serialized_tokens = false !== $serialized_tokens ? $serialized_tokens : array();
		$limit             = max( count( $original_tokens ), count( $serialized_tokens ) );

		for ( $index = 0; $index < $limit; ++$index ) {
			$original_token   = $original_tokens[ $index ] ?? null;
			$serialized_token = $serialized_tokens[ $index ] ?? null;
			if ( $original_token !== $serialized_token ) {
				return array(
					'index'      => $index,
					'original'   => null === $original_token ? null : Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( (string) $original_token ),
					'serialized' => null === $serialized_token ? null : Static_Site_Importer_Report_Diagnostics::diagnostic_excerpt( (string) $serialized_token ),
				);
			}
		}

		return array();
	}
}
