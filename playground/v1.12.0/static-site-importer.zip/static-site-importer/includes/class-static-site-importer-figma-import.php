<?php
/**
 * Figma import adapter.
 *
 * @package StaticSiteImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Static_Site_Importer_Artifact_Run_Workspace' ) ) {
	require_once __DIR__ . '/class-static-site-importer-artifact-run.php';
}

if ( ! class_exists( 'Static_Site_Importer_Website_Artifact_Import_Input' ) ) {
	require_once __DIR__ . '/class-static-site-importer-website-artifact-import-input.php';
}
if ( ! class_exists( 'Static_Site_Importer_Content_Policy' ) ) {
	require_once __DIR__ . '/class-static-site-importer-content-policy.php';
}

/**
 * Converts Figma import requests into website artifacts and imports them.
 */
class Static_Site_Importer_Figma_Import {
	/**
	 * Whether this runtime can decode zstd-compressed Figma chunks.
	 */
	public static function zstd_decoder_available(): bool {
		$command   = self::zstd_command();
		$available = function_exists( 'zstd_uncompress' )
			|| ( class_exists( '\\Automattic\\BlocksEngine\\FigmaTransformer\\Compression\\ZstdCommandDecoder' ) && self::zstd_command_decodes_probe( $command ) );

		/**
		 * Filters whether direct .fig intake is available in this runtime.
		 *
		 * Hosts that register a custom transformer decoder may advertise that
		 * capability here without requiring the native extension or command adapter.
		 *
		 * @param bool $available Whether a zstd decoder is available.
		 */
		return (bool) apply_filters( 'static_site_importer_figma_zstd_available', $available );
	}

	/**
	 * Register the default Zstandard decoder for .fig uploads.
	 */
	public static function register_default_zstd_decoder(): void {
		if ( ! function_exists( 'add_filter' ) ) {
			return;
		}

		add_filter(
			'blocks_engine_figma_transformer_zstd_decoder',
			static function ( $decoder ) {
				if ( is_callable( $decoder ) ) {
					return $decoder;
				}

				if ( function_exists( 'zstd_uncompress' ) ) {
					return static function ( string $compressed ): string {
						return (string) zstd_uncompress( $compressed );
					};
				}

				if ( ! class_exists( '\\Automattic\\BlocksEngine\\FigmaTransformer\\Compression\\ZstdCommandDecoder' ) ) {
					return $decoder;
				}

				$command = self::zstd_command();
				if ( empty( $command ) ) {
					return $decoder;
				}

				return new \Automattic\BlocksEngine\FigmaTransformer\Compression\ZstdCommandDecoder( $command );
			}
		);
	}

	/**
	 * Compatibility adapter for canonical Figma imports.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>
	 */
	public static function import( array $input ): array {
		$source          = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();
		$source['type']  = 'figma';
		$input['source'] = $source;

		return static_site_importer_ability_import( $input );
	}

	/**
	 * Normalize a Figma source for the canonical import service.
	 *
	 * @param array<string,mixed> $input Canonical import input.
	 * @return array{artifact:array<string,mixed>,input:array<string,mixed>}|WP_Error
	 */
	public static function prepare_import( array $input ) {
		$artifact = self::website_artifact_from_input( $input );
		if ( is_wp_error( $artifact ) ) {
			return $artifact;
		}

		$import_input         = self::import_input( $input, $artifact );
		$validation_artifacts = self::validation_artifacts( $input, $artifact, $import_input );
		if ( ! empty( $validation_artifacts ) ) {
			$import_input['validation_artifacts'] = $validation_artifacts;
		}
		return array(
			'artifact' => $artifact,
			'input'    => $import_input,
		);
	}

	/**
	 * Diagnose a Figma runner request through the production transform boundary.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function diagnostics_report( array $input ) {
		$artifact = self::website_artifact_from_input( $input );
		if ( is_wp_error( $artifact ) ) {
			return $artifact;
		}

		$import_input = self::import_input( $input, $artifact );

		$source_metadata        = isset( $import_input['source_metadata'] ) && is_array( $import_input['source_metadata'] ) ? $import_input['source_metadata'] : array();
		$figma_transform_report = self::figma_transform_report_from_metadata( $source_metadata );
		$transform_diagnostics  = self::transform_diagnostics_from_report( $figma_transform_report );

		return array(
			'schema'                  => 'static-site-importer/figma-diagnostics/v1',
			'success'                 => true,
			'request'                 => self::diagnostics_request_summary( $input ),
			'artifact'                => self::diagnostics_artifact_summary( $artifact ),
			'figma_transform_report'  => $figma_transform_report,
			'transform_diagnostics'   => $transform_diagnostics,
			'production_import_input' => array(
				'slug'      => (string) ( $import_input['slug'] ?? '' ),
				'name'      => (string) ( $import_input['name'] ?? '' ),
				'activate'  => (bool) ( $import_input['activate'] ?? false ),
				'overwrite' => (bool) ( $import_input['overwrite'] ?? false ),
			),
		);
	}

	/**
	 * Summarize the Figma request without echoing the full design payload.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>
	 */
	private static function diagnostics_request_summary( array $input ): array {
		$scenegraph = self::scenegraph_from_input( $input );
		$source     = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();

		return array_filter(
			array(
				'has_scenegraph'  => ! empty( $scenegraph ),
				'has_bundle'      => isset( $input['artifact_bundle'] ) && is_array( $input['artifact_bundle'] ),
				'frame_id'        => isset( $input['frame_id'] ) ? (string) $input['frame_id'] : '',
				'source_file_key' => isset( $source['fileKey'] ) ? (string) $source['fileKey'] : '',
				'node_ids'        => isset( $source['nodeIds'] ) && is_array( $source['nodeIds'] ) ? array_values( array_map( 'strval', $source['nodeIds'] ) ) : array(),
			)
		);
	}

	/**
	 * Summarize the generated website artifact boundary.
	 *
	 * @param array<string,mixed> $artifact Website artifact.
	 * @return array<string,mixed>
	 */
	private static function diagnostics_artifact_summary( array $artifact ): array {
		$files       = isset( $artifact['files'] ) && is_array( $artifact['files'] ) ? $artifact['files'] : array();
		$paths       = array();
		$asset_paths = array();

		foreach ( $files as $file ) {
			if ( ! is_array( $file ) || ! isset( $file['path'] ) || ! is_scalar( $file['path'] ) ) {
				continue;
			}

			$path    = (string) $file['path'];
			$paths[] = $path;
			if ( str_contains( $path, '/assets/' ) ) {
				$asset_paths[] = $path;
			}
		}

		return array(
			'schema'      => (string) ( $artifact['schema'] ?? '' ),
			'root'        => (string) ( $artifact['root'] ?? '' ),
			'entrypoint'  => (string) ( $artifact['entrypoint'] ?? '' ),
			'file_count'  => count( $paths ),
			'asset_count' => count( $asset_paths ),
			'asset_paths' => $asset_paths,
		);
	}

	/**
	 * Build a Figma plugin runner response for browser clients.
	 *
	 * @param array<string,mixed> $ability_result Ability result.
	 * @return array<string,mixed>
	 */
	public static function runner_response( array $ability_result ): array {
		if ( empty( $ability_result['success'] ) ) {
			$error = isset( $ability_result['error'] ) && is_array( $ability_result['error'] ) ? $ability_result['error'] : array();

			return array(
				'schema'  => 'figma-to-wordpress/runner-response/v1',
				'success' => false,
				'status'  => 'failed',
				'error'   => array(
					'code'    => (string) ( $error['code'] ?? 'static_site_importer_figma_import_failed' ),
					'message' => (string) ( $error['message'] ?? 'Figma import failed.' ),
					'data'    => $error['data'] ?? null,
				),
			);
		}

		$preview  = isset( $ability_result['preview'] ) && is_array( $ability_result['preview'] ) ? $ability_result['preview'] : array();
		$open_url = isset( $preview['url'] ) ? (string) $preview['url'] : '';

		$response = array(
			'schema'          => 'figma-to-wordpress/runner-response/v1',
			'success'         => true,
			'status'          => 'created',
			'open_url'        => '' !== $open_url ? $open_url : home_url( '/' ),
			'preview_session' => $preview,
			'materialization' => self::materialization_summary( $ability_result ),
		);

		$figma_transform_report = isset( $ability_result['figma_transform_report'] ) && is_array( $ability_result['figma_transform_report'] ) ? $ability_result['figma_transform_report'] : array();
		if ( ! empty( $figma_transform_report ) ) {
			$response['figma_transform_report'] = $figma_transform_report;
		}

		return $response;
	}

	/**
	 * Build a compact materialization summary for browser runner clients.
	 *
	 * @param array<string,mixed> $ability_result Import ability result.
	 * @return array<string,mixed>
	 */
	private static function materialization_summary( array $ability_result ): array {
		$result  = isset( $ability_result['result'] ) && is_array( $ability_result['result'] ) ? $ability_result['result'] : array();
		$summary = isset( $result['import_report_summary'] ) && is_array( $result['import_report_summary'] ) ? $result['import_report_summary'] : array();

		return array_filter(
			array(
				'success'          => ! empty( $ability_result['success'] ),
				'theme_slug'       => isset( $result['theme_slug'] ) ? (string) $result['theme_slug'] : '',
				'theme_name'       => isset( $result['theme_name'] ) ? (string) $result['theme_name'] : '',
				'pages'            => isset( $result['pages'] ) && is_array( $result['pages'] ) ? $result['pages'] : array(),
				'quality_pass'     => isset( $summary['quality_pass'] ) ? (bool) $summary['quality_pass'] : null,
				'diagnostic_count' => isset( $summary['diagnostic_count'] ) ? (int) $summary['diagnostic_count'] : null,
				'fallback_count'   => isset( $summary['fallback_count'] ) ? (int) $summary['fallback_count'] : null,
			)
		);
	}

	/**
	 * Build a website artifact from a Figma import request.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function website_artifact_from_input( array $input ) {
		$source     = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();
		$figma_file = self::figma_file_from_input( $input );
		if ( ! empty( $figma_file ) ) {
			return self::website_artifact_from_figma_file( $figma_file, $input );
		}

		$scenegraph = self::scenegraph_from_input( $input );
		if ( ! empty( $scenegraph ) ) {
			$artifact = self::website_artifact_from_scenegraph( $scenegraph, $input );
			if ( ! is_wp_error( $artifact ) || ! isset( $input['artifact_bundle'] ) || ! is_array( $input['artifact_bundle'] ) ) {
				return $artifact;
			}
		}

		$artifact_bundle = isset( $input['artifact_bundle'] ) && is_array( $input['artifact_bundle'] ) ? $input['artifact_bundle'] : ( isset( $source['artifact_bundle'] ) && is_array( $source['artifact_bundle'] ) ? $source['artifact_bundle'] : array() );
		if ( ! empty( $artifact_bundle ) ) {
			return self::website_artifact_from_bundle( $artifact_bundle, $input );
		}

		return new WP_Error( 'static_site_importer_figma_source_missing', 'Figma imports require an artifact_bundle or a Figma scenegraph.', array( 'status' => 400 ) );
	}

	/**
	 * Transform a server-side uploaded .fig temp file into a website artifact.
	 *
	 * @param string              $path  Uploaded temp file path.
	 * @param string              $name  Original uploaded file name.
	 * @param array<string,mixed> $input Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function website_artifact_from_figma_upload( string $path, string $name, array $input ) {
		return self::website_artifact_from_figma_file_path( $path, $name, $input );
	}

	/**
	 * Convert the current Figma plugin artifact bundle into a website artifact.
	 *
	 * @param array<string,mixed> $bundle Figma plugin artifact bundle.
	 * @param array<string,mixed> $input  Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function website_artifact_from_bundle( array $bundle, array $input ) {
		$files = self::normalize_files( isset( $bundle['files'] ) && is_array( $bundle['files'] ) ? $bundle['files'] : array(), (string) ( $bundle['root'] ?? 'website/' ) );
		if ( is_wp_error( $files ) ) {
			return $files;
		}
		if ( empty( $files ) ) {
			return new WP_Error( 'static_site_importer_figma_bundle_empty', 'The Figma artifact bundle did not contain importable files.', array( 'status' => 400 ) );
		}

		return array(
			'schema'     => 'blocks-engine/php-transformer/site-artifact/v1',
			'root'       => 'website',
			'entrypoint' => self::entrypoint( isset( $bundle['entrypoint'] ) ? (string) $bundle['entrypoint'] : '', $files ),
			'files'      => $files,
			'provenance' => self::provenance( $input ),
		);
	}

	/**
	 * Transform a raw Figma scenegraph into a website artifact.
	 *
	 * @param array<string,mixed> $scenegraph Figma scenegraph.
	 * @param array<string,mixed> $input      Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function website_artifact_from_scenegraph( array $scenegraph, array $input ) {
		if ( ! function_exists( 'blocks_engine_figma_transformer_transform_scenegraph' ) ) {
			return new WP_Error( 'static_site_importer_figma_transformer_unavailable', 'Blocks Engine Figma transformer is not available.', array( 'status' => 501 ) );
		}

		$transform = blocks_engine_figma_transformer_transform_scenegraph( $scenegraph, self::transform_options( $input ) );

		return self::website_artifact_from_transform( $transform, $input );
	}

	/**
	 * Transform an uploaded .fig file into a website artifact.
	 *
	 * @param array<string,mixed> $figma_file Uploaded .fig source payload.
	 * @param array<string,mixed> $input      Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function website_artifact_from_figma_file( array $figma_file, array $input ) {
		$name = isset( $figma_file['name'] ) ? (string) $figma_file['name'] : '';
		if ( isset( $figma_file['staged_path'] ) ) {
			return self::website_artifact_from_staged_figma_file( (string) $figma_file['staged_path'], $name, $input );
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decodes uploaded .fig payload content.
		$content = isset( $figma_file['content_base64'] ) ? base64_decode( (string) $figma_file['content_base64'], true ) : false;
		if ( false === $content ) {
			return new WP_Error( 'static_site_importer_figma_file_content_invalid', 'Uploaded .fig content could not be decoded.', array( 'status' => 400 ) );
		}

		$retention = ! empty( $input['retain_workspace'] ) ? array(
			'on_success' => 'retain',
			'on_failure' => 'retain',
			'expires_at' => gmdate( 'c', time() + 604800 ),
		) : array( 'on_success' => 'purge_on_success' );
		$temp_root = realpath( sys_get_temp_dir() );
		$workspace = new Static_Site_Importer_Artifact_Run_Workspace( false !== $temp_root ? $temp_root : sys_get_temp_dir(), 'fig-' . bin2hex( random_bytes( 8 ) ), $retention );
		$tmp       = $workspace->publish_raw( 'input.fig', $content );
		if ( is_wp_error( $tmp ) ) {
			return new WP_Error( 'static_site_importer_figma_file_tempfile_failed', 'Uploaded .fig file could not be staged for transformation.', array( 'status' => 500 ) );
		}

		try {
			$result = self::website_artifact_from_figma_file_path( $tmp, $name, $input );
			if ( ! is_wp_error( $result ) && ! empty( $input['retain_workspace'] ) ) {
				$result['provenance']['artifact_workspace'] = array(
					'path'       => $workspace->directory(),
					'expires_at' => $workspace->retention()['expires_at'] ?? null,
					'cleanup'    => $workspace->cleanup( 'failure' ),
				);
			}
			return $result;
		} finally {
			if ( empty( $input['retain_workspace'] ) ) {
				$workspace->cleanup( 'success' ); }
		}
	}

	/**
	 * Transform a Studio-staged .fig file without copying its bytes through JSON and PHP source.
	 *
	 * @param string              $path  Staged file path.
	 * @param string              $name  Original file name.
	 * @param array<string,mixed> $input Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function website_artifact_from_staged_figma_file( string $path, string $name, array $input ) {
		$staging_root = realpath( ABSPATH . '.studio-import' );
		$resolved     = realpath( $path );
		if ( false === $staging_root || false === $resolved ) {
			return new WP_Error( 'static_site_importer_figma_staged_file_invalid', 'Staged Figma file could not be resolved.', array( 'status' => 400 ) );
		}

		$normalized_root = rtrim( str_replace( '\\', '/', $staging_root ), '/' ) . '/';
		$normalized_path = str_replace( '\\', '/', $resolved );
		if ( ! str_starts_with( $normalized_path, $normalized_root ) || is_link( $path ) || ! is_file( $resolved ) || ! is_readable( $resolved ) ) {
			return new WP_Error( 'static_site_importer_figma_staged_file_invalid', 'Staged Figma file must be a readable regular file inside the Studio import directory.', array( 'status' => 400 ) );
		}

		if ( ! preg_match( '/\.fig$/i', $name ) || ! preg_match( '/\.fig$/i', $normalized_path ) ) {
			return new WP_Error( 'static_site_importer_figma_file_type_invalid', 'Staged Figma files must use the .fig extension.', array( 'status' => 400 ) );
		}

		return self::website_artifact_from_figma_file_path( $resolved, $name, $input );
	}

	/**
	 * Transform a local .fig file path into a website artifact.
	 *
	 * @param string              $path  Local .fig file path.
	 * @param string              $name  Original file name.
	 * @param array<string,mixed> $input Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function website_artifact_from_figma_file_path( string $path, string $name, array $input ) {
		if ( ! function_exists( 'blocks_engine_figma_transformer_transform_file' ) ) {
			return new WP_Error( 'static_site_importer_figma_transformer_unavailable', 'Blocks Engine Figma transformer is not available.', array( 'status' => 501 ) );
		}
		if ( ! self::zstd_decoder_available() ) {
			return new WP_Error( 'static_site_importer_figma_zstd_unavailable', 'Figma file import requires zstd support in this runtime.', array( 'status' => 501 ) );
		}

		if ( ! preg_match( '/\.fig$/i', $name ) ) {
			return new WP_Error( 'static_site_importer_figma_file_type_invalid', 'Figma file uploads must use a .fig file.', array( 'status' => 400 ) );
		}

		if ( '' === $path || ! is_readable( $path ) ) {
			return new WP_Error( 'static_site_importer_figma_file_unreadable', 'Uploaded .fig file could not be read.', array( 'status' => 400 ) );
		}

		$transform = blocks_engine_figma_transformer_transform_file( $path, self::transform_options( $input ) );

		return self::website_artifact_from_transform( $transform, $input );
	}

	/**
	 * Convert a Blocks Engine Figma transform result into SSI's website artifact shape.
	 *
	 * @param mixed               $transform Transform result.
	 * @param array<string,mixed> $input     Full request input.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function website_artifact_from_transform( $transform, array $input ) {
		if ( is_object( $transform ) && is_callable( array( $transform, 'toArray' ) ) ) {
			$transform = $transform->toArray();
		}
		if ( ! is_array( $transform ) ) {
			return new WP_Error( 'static_site_importer_figma_transform_failed', 'Blocks Engine Figma transformer returned an invalid result.', array( 'status' => 500 ) );
		}
		if ( isset( $transform['status'] ) && 'failed' === (string) $transform['status'] ) {
			return new WP_Error(
				'static_site_importer_figma_transform_failed',
				'Blocks Engine Figma transformer failed.',
				array(
					'status'    => 500,
					'transform' => $transform,
				)
			);
		}

		$files = self::normalize_files( isset( $transform['files'] ) && is_array( $transform['files'] ) ? $transform['files'] : array(), 'website/' );
		if ( is_wp_error( $files ) ) {
			return $files;
		}
		if ( empty( $files ) ) {
			$diagnostic = self::first_transform_diagnostic( $transform );
			$data       = array(
				'status'    => 500,
				'transform' => $transform,
			);
			if ( ! empty( $diagnostic ) ) {
				$data['diagnostic'] = $diagnostic;
			}

			return new WP_Error( 'static_site_importer_figma_transform_empty', self::empty_transform_message( $diagnostic ), $data );
		}

		$provenance = self::provenance( $input ) + array( 'transform' => 'blocks-engine/figma-transformer' );
		$report     = self::figma_transform_report_from_transform( $transform );
		if ( ! empty( $report ) ) {
			$provenance['figma_transform_report'] = $report;
		}

		return array(
			'schema'     => 'blocks-engine/php-transformer/site-artifact/v1',
			'root'       => 'website',
			'entrypoint' => self::entrypoint( 'website/index.html', $files ),
			'files'      => $files,
			'provenance' => $provenance,
		);
	}

	/**
	 * Extract durable Figma transform diagnostics from a Blocks Engine result.
	 *
	 * @param array<string,mixed> $transform Blocks Engine Figma transform result.
	 * @return array<string,mixed>
	 */
	private static function figma_transform_report_from_transform( array $transform ): array {
		$source_reports = isset( $transform['source_reports'] ) && is_array( $transform['source_reports'] ) ? $transform['source_reports'] : array();
		$figma_report   = isset( $source_reports['figma'] ) && is_array( $source_reports['figma'] ) ? $source_reports['figma'] : array();
		if ( empty( $figma_report ) ) {
			return array();
		}

		return array(
			'schema'         => 'static-site-importer/figma-transform-report/v1',
			'source'         => 'blocks-engine/figma-transformer',
			'status'         => isset( $transform['status'] ) && is_scalar( $transform['status'] ) ? (string) $transform['status'] : '',
			'summary'        => self::figma_transform_summary( $figma_report, $transform ),
			'source_reports' => array(
				'figma' => $figma_report,
			),
		);
	}

	/**
	 * Build a compact, stable summary of transformer quality diagnostics.
	 *
	 * @param array<string,mixed> $figma_report Raw Blocks Engine Figma report.
	 * @param array<string,mixed> $transform    Full transform result.
	 * @return array<string,mixed>
	 */
	private static function figma_transform_summary( array $figma_report, array $transform ): array {
		$page_plan        = isset( $figma_report['pages'] ) && is_array( $figma_report['pages'] ) ? $figma_report['pages'] : array();
		$pages            = isset( $page_plan['pages'] ) && is_array( $page_plan['pages'] ) ? $page_plan['pages'] : array();
		$diagnostics      = isset( $transform['diagnostics'] ) && is_array( $transform['diagnostics'] ) ? $transform['diagnostics'] : array();
		$artifact_quality = self::first_nested_array( $figma_report, array( 'artifact_quality' ) );

		$selected_pages = array();
		$page_warnings  = array();
		foreach ( $pages as $page ) {
			if ( ! is_array( $page ) ) {
				continue;
			}

			$page_summary = array_filter(
				array(
					'path'     => isset( $page['path'] ) && is_scalar( $page['path'] ) ? (string) $page['path'] : '',
					'name'     => isset( $page['name'] ) && is_scalar( $page['name'] ) ? (string) $page['name'] : '',
					'frame_id' => isset( $page['frame_id'] ) && is_scalar( $page['frame_id'] ) ? (string) $page['frame_id'] : '',
					'role'     => isset( $page['role'] ) && is_scalar( $page['role'] ) ? (string) $page['role'] : '',
				)
			);
			if ( ! empty( $page_summary ) ) {
				$selected_pages[] = $page_summary;
			}

			foreach ( isset( $page['diagnostics'] ) && is_array( $page['diagnostics'] ) ? $page['diagnostics'] : array() as $diagnostic ) {
				if ( is_array( $diagnostic ) ) {
					$page_warnings[] = array_merge( $page_summary, self::compact_diagnostic( $diagnostic ) );
				}
			}
		}

		return array(
			'artifact_quality'   => self::compact_artifact_quality( $artifact_quality ),
			'page_coverage'      => array(
				'candidate_count' => isset( $page_plan['candidate_count'] ) && is_numeric( $page_plan['candidate_count'] ) ? (int) $page_plan['candidate_count'] : count( $pages ),
				'selected_count'  => count( $selected_pages ),
				'page_count'      => isset( $page_plan['page_count'] ) && is_numeric( $page_plan['page_count'] ) ? (int) $page_plan['page_count'] : count( $selected_pages ),
			),
			'selected_pages'     => $selected_pages,
			'omitted_pages'      => self::compact_named_rows( self::first_nested_array( $figma_report, array( 'omitted_pages', 'omittedFrames', 'omitted_frames' ) ) ),
			'selected_templates' => self::compact_named_rows( self::first_nested_array( $figma_report, array( 'selected_templates', 'selectedTemplates' ) ) ),
			'omitted_templates'  => self::compact_named_rows( self::first_nested_array( $figma_report, array( 'omitted_templates', 'omittedTemplates' ) ) ),
			'missing_assets'     => self::compact_named_rows( self::first_nested_array( $figma_report, array( 'missing_assets', 'missingAssets' ) ) ),
			'page_warnings'      => $page_warnings,
			'diagnostic_counts'  => self::diagnostic_counts( $diagnostics ),
		);
	}

	/**
	 * Return the first nested array value matching any key.
	 *
	 * @param mixed             $value Source value.
	 * @param array<int,string> $keys  Candidate keys.
	 * @return array<string|int,mixed>
	 */
	private static function first_nested_array( $value, array $keys ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}

		foreach ( $keys as $key ) {
			if ( isset( $value[ $key ] ) && is_array( $value[ $key ] ) ) {
				return $value[ $key ];
			}
		}

		foreach ( $value as $child ) {
			$found = self::first_nested_array( $child, $keys );
			if ( ! empty( $found ) ) {
				return $found;
			}
		}

		return array();
	}

	/**
	 * Keep only stable, compact fields from a diagnostic row.
	 *
	 * @param array<string,mixed> $diagnostic Diagnostic row.
	 * @return array<string,mixed>
	 */
	private static function compact_diagnostic( array $diagnostic ): array {
		$compact = array();
		foreach ( array( 'severity', 'code', 'message', 'source', 'reason', 'reason_code' ) as $key ) {
			if ( isset( $diagnostic[ $key ] ) && is_scalar( $diagnostic[ $key ] ) ) {
				$compact[ $key ] = (string) $diagnostic[ $key ];
			}
		}

		return $compact;
	}

	/**
	 * Compact an artifact quality report.
	 *
	 * @param array<string|int,mixed> $quality Artifact quality report.
	 * @return array<string,mixed>
	 */
	private static function compact_artifact_quality( array $quality ): array {
		if ( empty( $quality ) ) {
			return array();
		}

		return array_filter(
			array(
				'status'         => isset( $quality['status'] ) && is_scalar( $quality['status'] ) ? (string) $quality['status'] : '',
				'quality_status' => isset( $quality['quality_status'] ) && is_scalar( $quality['quality_status'] ) ? (string) $quality['quality_status'] : '',
				'summary'        => isset( $quality['summary'] ) && is_array( $quality['summary'] ) ? $quality['summary'] : array(),
				'signals'        => isset( $quality['signals'] ) && is_array( $quality['signals'] ) ? array_values( array_filter( array_map( static fn ( $signal ) => is_array( $signal ) ? self::compact_diagnostic( $signal ) : array(), $quality['signals'] ) ) ) : array(),
			)
		);
	}

	/**
	 * Compact a list of page/template/asset rows.
	 *
	 * @param array<string|int,mixed> $rows Raw rows.
	 * @return array<int,array<string,mixed>>
	 */
	private static function compact_named_rows( array $rows ): array {
		$compact = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$item = array();
			foreach ( array( 'path', 'name', 'frame_id', 'node_id', 'template', 'reason', 'reason_code', 'message' ) as $key ) {
				if ( isset( $row[ $key ] ) && is_scalar( $row[ $key ] ) ) {
					$item[ $key ] = (string) $row[ $key ];
				}
			}
			if ( ! empty( $item ) ) {
				$compact[] = $item;
			}
		}

		return $compact;
	}

	/**
	 * Count transform diagnostics by severity and code.
	 *
	 * @param array<int,mixed> $diagnostics Diagnostics.
	 * @return array<string,mixed>
	 */
	private static function diagnostic_counts( array $diagnostics ): array {
		$counts = array(
			'total'       => 0,
			'by_severity' => array(),
			'by_code'     => array(),
		);
		foreach ( $diagnostics as $diagnostic ) {
			if ( ! is_array( $diagnostic ) ) {
				continue;
			}

			++$counts['total'];
			$severity                           = isset( $diagnostic['severity'] ) && is_scalar( $diagnostic['severity'] ) ? (string) $diagnostic['severity'] : 'unknown';
			$code                               = isset( $diagnostic['code'] ) && is_scalar( $diagnostic['code'] ) ? (string) $diagnostic['code'] : 'unknown';
			$counts['by_severity'][ $severity ] = ( $counts['by_severity'][ $severity ] ?? 0 ) + 1;
			$counts['by_code'][ $code ]         = ( $counts['by_code'][ $code ] ?? 0 ) + 1;
		}

		return $counts;
	}

	/**
	 * Return the first useful transformer diagnostic for an empty Figma result.
	 *
	 * @param array<string,mixed> $transform Transform result.
	 * @return array<string,mixed>
	 */
	private static function first_transform_diagnostic( array $transform ): array {
		$diagnostics = isset( $transform['diagnostics'] ) && is_array( $transform['diagnostics'] ) ? $transform['diagnostics'] : array();
		foreach ( $diagnostics as $diagnostic ) {
			if ( is_array( $diagnostic ) ) {
				return $diagnostic;
			}
		}

		return array();
	}

	/**
	 * Build a concise empty-transform error message with transformer context.
	 *
	 * @param array<string,mixed> $diagnostic First transformer diagnostic.
	 */
	private static function empty_transform_message( array $diagnostic ): string {
		$message = 'Blocks Engine Figma transformer did not produce importable files.';
		if ( ! empty( $diagnostic['message'] ) && is_scalar( $diagnostic['message'] ) ) {
			$message .= ' ' . (string) $diagnostic['message'];
		}

		return $message;
	}

	/**
	 * Resolve an available zstd command for decoding compressed Figma chunks.
	 *
	 * @return array<int,string>
	 */
	private static function zstd_command(): array {
		$configured = defined( 'STATIC_SITE_IMPORTER_FIGMA_ZSTD_COMMAND' ) ? (string) STATIC_SITE_IMPORTER_FIGMA_ZSTD_COMMAND : '';
		if ( '' === $configured ) {
			$configured = (string) getenv( 'STATIC_SITE_IMPORTER_FIGMA_ZSTD_COMMAND' );
		}

		if ( '' !== $configured ) {
			return is_executable( $configured ) ? array( $configured, '-dc' ) : array();
		}

		foreach ( array( '/opt/homebrew/bin/zstd', '/usr/local/bin/zstd', '/usr/bin/zstd' ) as $candidate ) {
			if ( is_executable( $candidate ) ) {
				return array( $candidate, '-dc' );
			}
		}

		return array();
	}

	/**
	 * Prove a command can decode a bounded known zstd frame before advertising it.
	 *
	 * @param array<int,string> $command Command argv.
	 */
	private static function zstd_command_decodes_probe( array $command ): bool {
		if ( empty( $command ) || ! function_exists( 'proc_open' ) ) {
			return false;
		}

		static $results = array();
		$key            = hash( 'sha256', implode( "\0", $command ) );
		if ( array_key_exists( $key, $results ) ) {
			return $results[ $key ];
		}

		$compressed = hex2bin( '28b52ffd04587100007373692d7a7374642d70726f626554171147' );
		if ( false === $compressed ) {
			$results[ $key ] = false;
			return false;
		}

		try {
			$decoder = new \Automattic\BlocksEngine\FigmaTransformer\Compression\ZstdCommandDecoder( $command );
			$result  = $decoder( $compressed, array( 'max_decoded_bytes' => 64 ) );
		} catch ( \Throwable ) {
			$results[ $key ] = false;
			return false;
		}

		$results[ $key ] = 'ssi-zstd-probe' === ( $result['data'] ?? null );
		return $results[ $key ];
	}

	/**
	 * Read the durable Figma transform report from generic SSI metadata.
	 *
	 * @param array<string,mixed> $metadata SSI source metadata/provenance.
	 * @return array<string,mixed>
	 */
	private static function figma_transform_report_from_metadata( array $metadata ): array {
		$report = isset( $metadata['figma_transform_report'] ) && is_array( $metadata['figma_transform_report'] ) ? $metadata['figma_transform_report'] : array();

		return $report;
	}

	/**
	 * Extract the existing compact diagnostics bucket from the transform report.
	 *
	 * @param array<string,mixed> $report Durable Figma transform report.
	 * @return array<string,mixed>
	 */
	private static function transform_diagnostics_from_report( array $report ): array {
		$diagnostics = $report['source_reports']['figma']['html']['transform_diagnostics'] ?? array();

		return is_array( $diagnostics ) ? $diagnostics : array();
	}

	/**
	 * Extract the uploaded .fig file payload from supported request shapes.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>
	 */
	private static function figma_file_from_input( array $input ): array {
		if ( isset( $input['figma_file'] ) && is_array( $input['figma_file'] ) ) {
			return $input['figma_file'];
		}

		$source = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();
		if ( isset( $source['figma_file'] ) && is_array( $source['figma_file'] ) ) {
			return $source['figma_file'];
		}

		return array();
	}

	/**
	 * Normalize import files into the website/ artifact root.
	 *
	 * @param array<int,array<string,mixed>> $files Files.
	 * @param string                         $root  Source root.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private static function normalize_files( array $files, string $root ) {
		$normalized = array();
		$root       = trim( str_replace( '\\', '/', $root ), '/' );
		foreach ( $files as $file ) {
			if ( ! isset( $file['path'] ) ) {
				continue;
			}

			$path = self::artifact_path( (string) $file['path'], $root );
			if ( '' === $path ) {
				continue;
			}

			$record = array( 'path' => $path );
			if ( isset( $file['content_base64'] ) ) {
				$record['content_base64'] = (string) $file['content_base64'];
			} elseif ( array_key_exists( 'content', $file ) ) {
				if ( ! is_scalar( $file['content'] ) ) {
					return new WP_Error(
						'static_site_importer_figma_file_payload_invalid',
						'Figma transformer artifact file content must be scalar.',
						array(
							'status' => 400,
							'path'   => $path,
						)
					);
				}

				$content = (string) $file['content'];
				if ( Static_Site_Importer_Content_Policy::is_textual_path( $path ) ) {
					$record['content'] = $content;
				} else {
					$record['content_base64'] = base64_encode( $content ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Preserves binary transformer output across the textual artifact compiler boundary.
				}
			} else {
				return new WP_Error(
					'static_site_importer_figma_file_payload_missing',
					'Figma transformer artifact file entries must include content or content_base64 when no local artifact root is available.',
					array(
						'status' => 400,
						'path'   => $path,
					)
				);
			}

			if ( isset( $file['mime_type'] ) ) {
				$record['mime_type'] = (string) $file['mime_type'];
			}

			$normalized[] = $record;
		}

		return $normalized;
	}

	/**
	 * Normalize an artifact path under website/.
	 */
	private static function artifact_path( string $path, string $root ): string {
		$path = str_replace( '\\', '/', $path );
		$path = preg_replace( '#(^|/)\.\.(?=/|$)#', '', $path );
		$path = preg_replace( '#[^A-Za-z0-9_./-]#', '-', (string) $path );
		$path = trim( preg_replace( '#/+#', '/', (string) $path ), '/' );

		if ( '' !== $root && str_starts_with( $path, $root . '/' ) ) {
			$path = substr( $path, strlen( $root ) + 1 );
		}

		return '' === $path ? '' : 'website/' . ltrim( $path, '/' );
	}

	/**
	 * Pick the entrypoint file.
	 *
	 * @param string                         $entrypoint Requested entrypoint.
	 * @param array<int,array<string,mixed>> $files      Normalized files.
	 */
	private static function entrypoint( string $entrypoint, array $files ): string {
		$paths      = array_map( static fn( array $file ): string => (string) ( $file['path'] ?? '' ), $files );
		$entrypoint = self::artifact_path( $entrypoint, 'website' );

		if ( '' !== $entrypoint && in_array( $entrypoint, $paths, true ) ) {
			return $entrypoint;
		}

		return in_array( 'website/index.html', $paths, true ) ? 'website/index.html' : (string) reset( $paths );
	}

	/**
	 * Extract a scenegraph from supported request shapes.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>
	 */
	private static function scenegraph_from_input( array $input ): array {
		if ( isset( $input['scenegraph'] ) && is_array( $input['scenegraph'] ) ) {
			return $input['scenegraph'];
		}
		if ( isset( $input['figma'] ) && is_array( $input['figma'] ) ) {
			$figma = $input['figma'];
			if ( isset( $figma['scenegraph'] ) && is_array( $figma['scenegraph'] ) ) {
				return $figma['scenegraph'];
			}

			return $figma;
		}
		$source = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();
		if ( isset( $source['scenegraph'] ) && is_array( $source['scenegraph'] ) ) {
			return $source['scenegraph'];
		}
		if ( isset( $source['figma'] ) && is_array( $source['figma'] ) ) {
			return isset( $source['figma']['scenegraph'] ) && is_array( $source['figma']['scenegraph'] ) ? $source['figma']['scenegraph'] : $source['figma'];
		}

		return array();
	}

	/**
	 * Collect runtime validation artifact refs when the runner requests visual/block validation.
	 *
	 * @param array<string,mixed> $input        Figma import input.
	 * @param array<string,mixed> $artifact     Website artifact.
	 * @param array<string,mixed> $import_input Import args.
	 * @return array<string,mixed>
	 */
	private static function validation_artifacts( array $input, array $artifact, array $import_input ): array {
		if ( isset( $input['validation_artifacts'] ) && is_array( $input['validation_artifacts'] ) ) {
			return $input['validation_artifacts'];
		}

		$validation = isset( $input['validation'] ) && is_array( $input['validation'] ) ? $input['validation'] : array();
		if ( empty( $validation ) || ( array_key_exists( 'enabled', $validation ) && empty( $validation['enabled'] ) ) ) {
			return array();
		}

		if ( empty( $validation['visual_parity'] ) && empty( $validation['block_validation'] ) ) {
			return array();
		}

		if ( ! class_exists( 'Static_Site_Importer_Validation_Runtime' ) ) {
			return array();
		}

		$result = Static_Site_Importer_Validation_Runtime::validate_artifact(
			array(
				'artifact'         => $artifact,
				'slug'             => $import_input['slug'] ?? '',
				'name'             => $import_input['name'] ?? '',
				'activate'         => false,
				'overwrite'        => true,
				'compiler_options' => isset( $import_input['compiler_options'] ) && is_array( $import_input['compiler_options'] ) ? $import_input['compiler_options'] : array(),
				'source_metadata'  => isset( $import_input['source_metadata'] ) && is_array( $import_input['source_metadata'] ) ? $import_input['source_metadata'] : array(),
			)
		);

		if ( is_wp_error( $result ) ) {
			return array();
		}

		return self::validation_artifacts_from_validation_result( $result );
	}

	/**
	 * Map validation result refs into SSI visual parity artifact slots.
	 *
	 * @param array<string,mixed> $result Validation result.
	 * @return array<string,mixed>
	 */
	private static function validation_artifacts_from_validation_result( array $result ): array {
		$artifacts   = isset( $result['artifacts'] ) && is_array( $result['artifacts'] ) ? $result['artifacts'] : array();
		$screenshots = isset( $artifacts['screenshots'] ) && is_array( $artifacts['screenshots'] ) ? array_values( $artifacts['screenshots'] ) : array();
		$diffs       = isset( $artifacts['diffs'] ) && is_array( $artifacts['diffs'] ) ? array_values( $artifacts['diffs'] ) : array();

		return array_filter(
			array(
				'browser_render'      => isset( $artifacts['browser_render_evidence'] ) && is_array( $artifacts['browser_render_evidence'] ) ? $artifacts['browser_render_evidence'] : array(),
				'block_validation'    => isset( $artifacts['block_validation_result'] ) && is_array( $artifacts['block_validation_result'] ) ? $artifacts['block_validation_result'] : array(),
				'source_screenshot'   => isset( $screenshots[0] ) && is_array( $screenshots[0] ) ? $screenshots[0] : array(),
				'imported_screenshot' => isset( $screenshots[1] ) && is_array( $screenshots[1] ) ? $screenshots[1] : array(),
				'visual_diff'         => isset( $diffs[0] ) && is_array( $diffs[0] ) ? $diffs[0] : array(),
				'import_validation'   => $result,
			),
			static fn( mixed $value ): bool => array() !== $value
		);
	}

	/**
	 * Build import ability input from Figma request fields.
	 *
	 * @param array<string,mixed> $input    Figma import input.
	 * @param array<string,mixed> $artifact Website artifact.
	 * @return array<string,mixed>
	 */
	public static function import_input( array $input, array $artifact ): array {
		$title = self::display_title( $input, $artifact );

		$source_metadata = array_merge(
			isset( $input['source_metadata'] ) && is_array( $input['source_metadata'] ) ? $input['source_metadata'] : array(),
			isset( $artifact['provenance'] ) && is_array( $artifact['provenance'] ) ? $artifact['provenance'] : self::provenance( $input )
		);

		$input['name']            = isset( $input['name'] ) ? (string) $input['name'] : $title;
		$input['site_title']      = $title;
		$input['source_metadata'] = $source_metadata;

		return array_merge(
			array( 'artifact' => $artifact ),
			Static_Site_Importer_Website_Artifact_Import_Input::normalize(
				$input,
				array(
					'activate'                 => true,
					'overwrite'                => true,
					'materialize_dependencies' => true,
				)
			)
		);
	}

	/**
	 * Derive a human-readable title for the imported site.
	 *
	 * @param array<string,mixed> $input    Figma import input.
	 * @param array<string,mixed> $artifact Website artifact.
	 */
	private static function display_title( array $input, array $artifact ): string {
		foreach ( array( 'site_title', 'title', 'name' ) as $key ) {
			if ( isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) && '' !== trim( (string) $input[ $key ] ) ) {
				return sanitize_text_field( (string) $input[ $key ] );
			}
		}

		$metadata = self::metadata_from_artifact( $artifact );
		if ( isset( $metadata['title'] ) && is_scalar( $metadata['title'] ) && '' !== trim( (string) $metadata['title'] ) ) {
			return sanitize_text_field( (string) $metadata['title'] );
		}

		$source = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();
		if ( isset( $source['name'] ) && is_scalar( $source['name'] ) && '' !== trim( (string) $source['name'] ) ) {
			return sanitize_text_field( (string) $source['name'] );
		}

		$figma = isset( $input['figma'] ) && is_array( $input['figma'] ) ? $input['figma'] : array();
		if ( isset( $figma['name'] ) && is_scalar( $figma['name'] ) && '' !== trim( (string) $figma['name'] ) ) {
			return sanitize_text_field( (string) $figma['name'] );
		}

		return 'Figma Import';
	}

	/**
	 * Read metadata.json from a website artifact when present.
	 *
	 * @param array<string,mixed> $artifact Website artifact.
	 * @return array<string,mixed>
	 */
	private static function metadata_from_artifact( array $artifact ): array {
		$files = isset( $artifact['files'] ) && is_array( $artifact['files'] ) ? $artifact['files'] : array();
		foreach ( $files as $file ) {
			if ( ! is_array( $file ) || ! isset( $file['path'] ) || ! is_scalar( $file['path'] ) ) {
				continue;
			}

			if ( 'website/metadata.json' !== (string) $file['path'] && 'metadata.json' !== (string) $file['path'] ) {
				continue;
			}

			$content = isset( $file['content'] ) && is_scalar( $file['content'] ) ? (string) $file['content'] : '';
			if ( '' === trim( $content ) ) {
				continue;
			}

			$decoded = json_decode( $content, true );
			return is_array( $decoded ) ? $decoded : array();
		}

		return array();
	}

	/**
	 * Build transformer options from request fields.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>
	 */
	private static function transform_options( array $input ): array {
		$options = isset( $input['transform_options'] ) && is_array( $input['transform_options'] ) ? $input['transform_options'] : array();
		if ( isset( $input['frame_id'] ) ) {
			$options['frame_id'] = (string) $input['frame_id'];
		}

		return $options;
	}

	/**
	 * Build provenance metadata for generated artifacts/imports.
	 *
	 * @param array<string,mixed> $input Figma import input.
	 * @return array<string,mixed>
	 */
	private static function provenance( array $input ): array {
		$source = isset( $input['source'] ) && is_array( $input['source'] ) ? $input['source'] : array();

		return array(
			'source'      => 'figma-to-wordpress',
			'schema'      => (string) ( $input['schema'] ?? 'static-site-importer/import-figma/v1' ),
			'figma'       => array_filter(
				array(
					'file_key'    => isset( $source['fileKey'] ) ? (string) $source['fileKey'] : '',
					'node_ids'    => isset( $source['nodeIds'] ) && is_array( $source['nodeIds'] ) ? array_values( array_map( 'strval', $source['nodeIds'] ) ) : array(),
					'exported_at' => isset( $source['exportedAt'] ) ? (string) $source['exportedAt'] : '',
				)
			),
			'import_goal' => isset( $input['goal'] ) ? (string) $input['goal'] : '',
		);
	}
}
