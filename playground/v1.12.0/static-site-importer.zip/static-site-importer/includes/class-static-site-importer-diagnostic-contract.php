<?php
/**
 * Static Site Importer diagnostic contract.
 *
 * @package StaticSiteImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Static_Site_Importer_Diagnostic_Loss_Classes' ) ) {
	require_once __DIR__ . '/class-static-site-importer-diagnostic-loss-classes.php';
}

/**
 * Normalizes importer-owned diagnostics for validation and repair loops.
 */
class Static_Site_Importer_Diagnostic_Contract {

	public const IMPORT_DIAGNOSTICS_SCHEMA     = 'static-site-importer/import-diagnostics/v1';
	private const BLOCK_PROVENANCE_LIMIT       = 50;
	private const BLOCK_PROVENANCE_STAGE_LIMIT = 2;

	/**
	 * Build an importer-owned diagnostics envelope from a validation/import result.
	 *
	 * @param array<string,mixed> $result Validation provider or synthesized result.
	 * @return array<string,mixed>
	 */
	public static function build( array $result ): array {
		$request       = isset( $result['request'] ) && is_array( $result['request'] ) ? $result['request'] : array();
		$import_args   = isset( $request['import_args'] ) && is_array( $request['import_args'] ) ? $request['import_args'] : array();
		$import_report = self::provider_import_report( $result );
		$summary       = isset( $result['summary'] ) && is_array( $result['summary'] ) ? $result['summary'] : array();
		$artifacts     = isset( $result['artifacts'] ) && is_array( $result['artifacts'] ) ? $result['artifacts'] : array();

		$quality_counts = self::quality_counts( $import_report, $summary, $result );

		$diagnostics = array_merge( self::diagnostic_rows( $result, $import_report ), self::quality_count_consistency_diagnostics( $quality_counts ) );
		$diagnostics = self::dedupe_diagnostics( $diagnostics );

		return array(
			'schema'                         => self::IMPORT_DIAGNOSTICS_SCHEMA,
			'fixture'                        => array(
				'slug' => isset( $result['slug'] ) && is_scalar( $result['slug'] ) ? (string) $result['slug'] : ( isset( $import_args['slug'] ) ? (string) $import_args['slug'] : '' ),
				'name' => isset( $result['name'] ) && is_scalar( $result['name'] ) ? (string) $result['name'] : ( isset( $import_args['name'] ) ? (string) $import_args['name'] : '' ),
			),
			'status'                         => isset( $result['status'] ) && is_scalar( $result['status'] ) ? (string) $result['status'] : '',
			'success'                        => ! empty( $result['success'] ),
			'quality_counts'                 => $quality_counts,
			'import_report_quality_counts'   => $quality_counts,
			'diagnostic_summary'             => self::diagnostic_summary( $diagnostics ),
			'diagnostics'                    => $diagnostics,
			'loss_class_summary'             => Static_Site_Importer_Diagnostic_Loss_Classes::counts( $diagnostics ),
			'by_repair_bucket'               => self::diagnostics_by_field( $diagnostics, 'repair_bucket' ),
			'by_loss_class'                  => self::diagnostics_by_field( $diagnostics, 'loss_class' ),
			'by_parser_owner'                => self::diagnostics_by_field( $diagnostics, 'parser_owner' ),
			'by_category'                    => self::diagnostics_by_field( $diagnostics, 'category' ),
			'top_parser_buckets'             => self::top_parser_buckets( $diagnostics ),
			'blocks_engine'                  => self::blocks_engine_summary( $import_report ),
			'materialization_receipt'        => self::materialization_receipt_summary( $result, $import_report ),
			'runtime_dependency_target_gaps' => self::runtime_dependency_target_gaps( $import_report ),
			'asset_diagnostics'              => self::diagnostics_matching_types( $diagnostics, array( 'asset', 'image', 'local_asset_not_materialized', 'missing_asset', 'dropped_image' ) ),
			'svg_diagnostics'                => self::diagnostics_matching_types( $diagnostics, array( 'svg', 'unsafe_inline_svg', 'svg_materialization_failure', 'svg_sprite_reference_failure' ) ),
			'button_style_loss_hints'        => self::diagnostics_matching_types( $diagnostics, array( 'button', 'style_loss', 'presentation_gap' ) ),
			'artifact_refs'                  => self::artifact_refs( $artifacts, $import_report ),
		);
	}

	/**
	 * Extract an import report from common provider result slots.
	 *
	 * @param array<string,mixed> $result Provider result.
	 * @return array<string,mixed>
	 */
	private static function provider_import_report( array $result ): array {
		foreach ( array( $result['import_report'] ?? null, $result['summary']['import_report'] ?? null, $result['artifacts']['import_report'] ?? null ) as $candidate ) {
			if ( is_array( $candidate ) && ( isset( $candidate['quality'] ) || isset( $candidate['diagnostics'] ) || isset( $candidate['blocks_engine'] ) ) ) {
				return $candidate;
			}
		}

		return array();
	}

	/**
	 * Read one finalized diagnostic set, with a bounded fallback for early failures.
	 *
	 * @param array<string,mixed> $result        Provider result.
	 * @param array<string,mixed> $import_report Import report.
	 * @return array<int,array<string,mixed>>
	 */
	private static function diagnostic_rows( array $result, array $import_report ): array {
		$finalized = $import_report['import_validation_result']['diagnostics'] ?? null;
		if ( is_array( $finalized ) ) {
			return self::normalize_diagnostic_rows( $finalized );
		}

		$sources    = array(
			array( $result['diagnostics'] ?? array(), '' ),
			array( $result['artifact_diagnostics']['diagnostics'] ?? array(), '' ),
			array( $result['import_validation_result']['diagnostics'] ?? array(), '' ),
			array( $result['materialization_receipt']['diagnostics'] ?? array(), '' ),
			array( $import_report['diagnostics'] ?? array(), '' ),
			array( $import_report['artifact_diagnostics']['diagnostics'] ?? array(), '' ),
		);
		$conversion = isset( $import_report['blocks_engine']['conversion_report'] ) && is_array( $import_report['blocks_engine']['conversion_report'] ) ? $import_report['blocks_engine']['conversion_report'] : array();
		foreach ( array( 'diagnostics', 'fallback_diagnostics', 'fallbacks', 'presentation_gaps', 'interaction_candidates' ) as $field ) {
			$sources[] = array( $conversion[ $field ] ?? array(), 'blocks_engine_conversion_report' );
		}
		$blocks_engine = isset( $import_report['blocks_engine'] ) && is_array( $import_report['blocks_engine'] ) ? $import_report['blocks_engine'] : array();
		$gaps          = isset( $blocks_engine['gutenberg_gaps'] ) && is_array( $blocks_engine['gutenberg_gaps'] ) ? $blocks_engine['gutenberg_gaps'] : array();
		foreach ( $gaps as &$gap ) {
			if ( is_array( $gap ) && ! isset( $gap['type'] ) && ! isset( $gap['code'] ) ) {
				$gap['type'] = 'gutenberg_gap';
			}
		}
		unset( $gap );
		$sources[] = array( $gaps, 'gutenberg_gaps' );
		$sources[] = array( $blocks_engine['semantic_parity']['findings'] ?? array(), 'semantic_parity' );
		$sources[] = array( self::runtime_dependency_target_gaps( $import_report ), '' );

		$rows = array();
		foreach ( $sources as list( $source, $stage ) ) {
			if ( is_array( $source ) ) {
				$rows = array_merge( $rows, self::normalize_diagnostic_rows( $source, $stage ) );
			}
		}

		return $rows;
	}

	/**
	 * Extract runtime dependency parity target gaps.
	 *
	 * @param array<string,mixed> $import_report Import report.
	 * @return array<int,array<string,mixed>>
	 */
	private static function runtime_dependency_target_gaps( array $import_report ): array {
		$runtime_dependency_parity = isset( $import_report['blocks_engine']['runtime_dependency_parity'] ) && is_array( $import_report['blocks_engine']['runtime_dependency_parity'] ) ? $import_report['blocks_engine']['runtime_dependency_parity'] : array();
		$rows                      = array();
		foreach ( array( 'findings', 'missing_dom_targets', 'unsupported_elements' ) as $field ) {
			if ( isset( $runtime_dependency_parity[ $field ] ) && is_array( $runtime_dependency_parity[ $field ] ) ) {
				$rows = array_merge( $rows, self::normalize_diagnostic_rows( $runtime_dependency_parity[ $field ], 'runtime_dependency_parity' ) );
			}
		}

		return $rows;
	}

	/**
	 * Normalize diagnostic rows to a stable consumer-facing subset.
	 *
	 * @param array<int|string,mixed> $rows          Raw diagnostic rows.
	 * @param string                  $default_stage Default stage.
	 * @return array<int,array<string,mixed>>
	 */
	private static function normalize_diagnostic_rows( array $rows, string $default_stage = '' ): array {
		$normalized = array();
		foreach ( array_values( $rows ) as $index => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			if ( self::is_report_only_diagnostic( $row ) || self::is_count_only_diagnostic( $row ) ) {
				continue;
			}

			// Compiler file-drop warnings carry no contract identity and would
			// classify as acceptable conversion here. Re-own them first so every
			// consumer path agrees with the finalized report.
			$row                            = Static_Site_Importer_Diagnostic_Loss_Classes::reown_compiler_file_drop( $row );
			$type                           = self::first_identifier( $row, array( 'type', 'kind', 'code', 'reason_code' ), 'diagnostic' );
			$reason_code                    = self::first_identifier( $row, array( 'reason_code', 'code', 'reason', 'kind', 'type' ), $type );
			$source_path                    = self::first_scalar( $row, array( 'source_path', 'path', 'source', 'file', 'script_path' ), '' );
			$repair_bucket                  = self::repair_bucket( $type, $reason_code, $row );
			$loss_class                     = Static_Site_Importer_Diagnostic_Loss_Classes::classify( array_merge( $row, array( 'repair_bucket' => $repair_bucket ) ) );
			$repair_bucket                  = self::repair_bucket_for_loss_class( $repair_bucket, $loss_class );
			$parser_owner                   = self::parser_owner( $type, $repair_bucket, $row );
			$diagnostic                     = array(
				'id'                      => self::first_scalar( $row, array( 'id' ), sprintf( 'diag-%03d-%s', $index + 1, sanitize_key( $type . '-' . $reason_code . '-' . $source_path ) ) ),
				'type'                    => sanitize_key( $type ),
				'kind'                    => sanitize_key( self::first_identifier( $row, array( 'kind', 'code', 'type' ), $type ) ),
				'severity'                => self::first_scalar( $row, array( 'severity', 'level' ), self::default_diagnostic_severity( $type ) ),
				'category'                => self::diagnostic_category( $type ),
				'group_key'               => $repair_bucket,
				'repair_bucket'           => $repair_bucket,
				'parser_owner'            => $parser_owner,
				'candidate_repo'          => $parser_owner,
				'repair_mode'             => self::repair_mode( $repair_bucket ),
				'reason_code'             => sanitize_key( $reason_code ),
				'source_path'             => $source_path,
				'path'                    => $source_path,
				'selector'                => self::first_scalar( $row, array( 'selector', 'target_selector', 'css_selector' ), '' ),
				'code'                    => self::first_scalar( $row, array( 'code', 'error_code' ), sanitize_key( $reason_code ) ),
				'stage'                   => self::first_scalar( $row, array( 'stage' ), $default_stage ),
				'owner'                   => self::first_scalar( $row, array( 'owner', 'engine', 'converter' ), $parser_owner ),
				'runtime_target_selector' => self::first_scalar( $row, array( 'runtime_target_selector', 'target_selector', 'target', 'selector' ), '' ),
				'missing_asset_path'      => self::missing_asset_path( $row ),
			);
			$diagnostic['loss_class']       = $loss_class;
			$diagnostic['diagnostic_class'] = $diagnostic['loss_class'];
			$diagnostic['repair_class']     = $diagnostic['repair_mode'];
			$diagnostic['acceptability']    = self::diagnostic_acceptability( $diagnostic['loss_class'] );
			$source_diagnostic              = self::source_diagnostic_identity( $row, $diagnostic );
			if ( ! empty( $source_diagnostic ) ) {
				$diagnostic['source_diagnostic'] = $source_diagnostic;
			}

			foreach ( array( 'message', 'reason', 'excerpt', 'source_snippet', 'source_html_preview', 'emitted_block_preview', 'observed_output', 'html_excerpt', 'block_name', 'block_path', 'script_path', 'element', 'tag_name', 'tag', 'src', 'href', 'expected', 'observed', 'suggested_primitive', 'diagnostic_code', 'mapped_provider', 'materialization_status', 'runtime_requirement', 'materialization_path', 'preservation_strategy', 'preservation_status', 'disposition', 'js_handling' ) as $field ) {
				$value = self::first_scalar( $row, array( $field ), '' );
				if ( '' !== $value ) {
					$diagnostic[ $field ] = $value;
				}
			}
			if ( isset( $row['references'] ) && is_array( $row['references'] ) ) {
				$diagnostic['references'] = $row['references'];
			}

			// Preserve the runtime-mapping signal a real provider sets when it
			// materializes a preserved island (e.g. a <form> mapped to working
			// form-provider blocks). The honest fixture gate treats a preserved
			// runtime island as acceptable only when this signal is truthy.
			foreach ( array( 'runtime_mapped', 'runtime_carried' ) as $signal ) {
				if ( ! empty( $row[ $signal ] ) ) {
					$diagnostic[ $signal ] = true;
				}
			}

			$normalized[] = array_filter(
				$diagnostic,
				static fn ( mixed $value ): bool => '' !== $value
			);
		}

		return $normalized;
	}

	/**
	 * Reconcile canonical compiler quality evidence with explicit materialization resolutions.
	 *
	 * @param array<string,mixed> $import_report Import report.
	 * @param array<string,mixed> $summary Provider summary.
	 * @param array<string,mixed> $result  Provider result.
	 * @return array<string,mixed>
	 */
	private static function quality_counts( array $import_report, array $summary, array $result ): array {
		$keys                              = array( 'block_count', 'fallback_count', 'unsupported_fallback_count', 'accepted_preserved_runtime_island_count', 'content_loss_count', 'empty_conversion_count', 'core_html_block_count', 'freeform_block_count', 'invalid_block_count', 'invalid_block_document_count', 'image_missing_source_count', 'unsafe_svg_count', 'svg_materialization_failure_count', 'svg_sprite_reference_failure_count', 'commerce_dependency_failures', 'interaction_candidate_count', 'runtime_dependency_parity_issue_count', 'semantic_parity_failure_count', 'unsafe_layout_constraint_count' );
		$compiler_quality                  = isset( $import_report['blocks_engine']['wordpress_site_plan']['quality'] ) && is_array( $import_report['blocks_engine']['wordpress_site_plan']['quality'] ) ? $import_report['blocks_engine']['wordpress_site_plan']['quality'] : array();
		$report_quality                    = isset( $import_report['quality'] ) && is_array( $import_report['quality'] ) ? $import_report['quality'] : $summary;
		$source_counts                     = self::quality_metric_values( $compiler_quality, $keys );
		$report_counts                     = self::quality_metric_values( $report_quality, $keys );
		$validation_counts                 = self::validation_quality_metric_values( self::import_validation_result( $result, $import_report ) );
		$compiler_diagnostic_count         = self::quality_metric_values( $compiler_quality, array( 'diagnostic_count' ) );
		$report_diagnostic_count           = self::quality_metric_values( $report_quality, array( 'diagnostic_count' ) );
		$validation_diagnostic_count       = array_intersect_key( $validation_counts, array( 'diagnostic_count' => true ) );
		$compiler_fallback_count_available = isset( $source_counts['fallback_count'] );
		$provenance                        = array();

		foreach ( $keys as $key ) {
			if ( ! isset( $source_counts[ $key ] ) && isset( $report_counts[ $key ] ) ) {
				$source_counts[ $key ] = $report_counts[ $key ];
			}
		}
		if ( ! empty( $validation_counts ) ) {
			$source_counts                         = array_merge( $source_counts, $validation_counts );
			$provenance['materialized_validation'] = array(
				'owner'   => 'static-site-importer',
				'path'    => 'import_validation_result.counts',
				'schema'  => (string) ( self::import_validation_result( $result, $import_report )['schema'] ?? '' ),
				'metrics' => 'import_validation_result.counts',
			);
		}
		if ( ! empty( $compiler_quality ) ) {
			$provenance['source_detected'] = array(
				'owner'   => 'blocks-engine',
				'path'    => 'blocks_engine.wordpress_site_plan.quality',
				'schema'  => isset( $import_report['blocks_engine']['wordpress_site_plan']['schema'] ) ? (string) $import_report['blocks_engine']['wordpress_site_plan']['schema'] : '',
				'metrics' => 'blocks_engine.wordpress_site_plan.quality.metrics',
			);
		} elseif ( ! empty( $report_quality ) ) {
			$provenance['source_detected'] = array(
				'owner'   => 'static-site-importer',
				'path'    => 'quality',
				'schema'  => isset( $import_report['schema'] ) ? (string) $import_report['schema'] : '',
				'metrics' => 'quality',
			);
		}

		$receipt                         = isset( $result['materialization_receipt'] ) && is_array( $result['materialization_receipt'] ) ? $result['materialization_receipt'] : ( isset( $import_report['materialization_receipt'] ) && is_array( $import_report['materialization_receipt'] ) ? $import_report['materialization_receipt'] : array() );
		$reconciliation                  = isset( $import_report['quality_resolutions'] ) && is_array( $import_report['quality_resolutions'] )
			? $import_report['quality_resolutions']
			: ( isset( $import_report['fallback_reconciliation'] ) && is_array( $import_report['fallback_reconciliation'] ) ? $import_report['fallback_reconciliation'] : array() );
		$resolved_counts                 = array();
		$source_fallback_count_available = isset( $reconciliation['source_fallback_count'] ) && is_numeric( $reconciliation['source_fallback_count'] );
		if ( ! isset( $validation_counts['fallback_count'] ) && ! $compiler_fallback_count_available && $source_fallback_count_available ) {
			$source_counts['fallback_count'] = max( 0, (int) $reconciliation['source_fallback_count'] );
			$provenance['source_detected']   = array(
				'owner'   => 'static-site-importer',
				'path'    => 'quality_resolutions.source_fallback_count',
				'schema'  => isset( $reconciliation['schema'] ) ? (string) $reconciliation['schema'] : '',
				'metrics' => 'quality_resolutions',
			);
		}
		$verified_resolutions = self::verified_provider_resolution_count( $reconciliation );
		if ( ! isset( $validation_counts['fallback_count'] ) && ( $compiler_fallback_count_available || $source_fallback_count_available ) && null !== $verified_resolutions ) {
			$resolved_counts['fallback_count'] = $verified_resolutions;
			$provenance['materialized']        = array(
				'owner'   => 'static-site-importer',
				'path'    => 'quality_resolutions',
				'schema'  => isset( $reconciliation['schema'] ) ? (string) $reconciliation['schema'] : '',
				'receipt' => isset( $receipt['schema'] ) ? (string) $receipt['schema'] : '',
			);
		}

		$counts = array();
		foreach ( $keys as $key ) {
			$source         = $source_counts[ $key ] ?? 0;
			$resolved       = isset( $validation_counts[ $key ] ) ? 0 : min( $source, $resolved_counts[ $key ] ?? 0 );
			$counts[ $key ] = $source - $resolved;
		}
		if ( $counts['block_count'] <= 0 ) {
			$document_counts = self::block_document_quality_counts( $import_report );
			if ( $document_counts['block_count'] > 0 ) {
				$counts = array_merge( $counts, $document_counts );
			}
		}
		$counts['diagnostic_count'] = $validation_diagnostic_count['diagnostic_count'] ?? $compiler_diagnostic_count['diagnostic_count'] ?? $report_diagnostic_count['diagnostic_count'] ?? 0;

		$counts['source_detected'] = array_merge( array_fill_keys( array_merge( $keys, array( 'diagnostic_count' ) ), 0 ), $source_counts, $compiler_diagnostic_count );
		$counts['materialized']    = array_merge( array_fill_keys( array_merge( $keys, array( 'diagnostic_count' ) ), 0 ), $resolved_counts );
		$counts['unresolved']      = array_intersect_key( $counts, array_flip( array_merge( $keys, array( 'diagnostic_count' ) ) ) );

		$counts['diagnostic_counts'] = array(
			'compiler'                => $compiler_diagnostic_count['diagnostic_count'] ?? null,
			'import_report'           => $report_diagnostic_count['diagnostic_count'] ?? null,
			'materialized_validation' => $validation_diagnostic_count['diagnostic_count'] ?? null,
		);

		$counts['diagnostic_count_provenance'] = array_filter(
			array(
				'compiler'                => isset( $compiler_diagnostic_count['diagnostic_count'] ) ? array(
					'owner' => 'blocks-engine',
					'path'  => 'blocks_engine.wordpress_site_plan.quality.' . ( is_array( $compiler_quality['metrics'] ?? null ) ? 'metrics.' : '' ) . 'diagnostic_count',
				) : null,
				'import_report'           => isset( $report_diagnostic_count['diagnostic_count'] ) ? array(
					'owner' => 'static-site-importer',
					'path'  => 'quality.' . ( is_array( $report_quality['metrics'] ?? null ) ? 'metrics.' : '' ) . 'diagnostic_count',
				) : null,
				'materialized_validation' => isset( $validation_diagnostic_count['diagnostic_count'] ) ? array(
					'owner' => 'static-site-importer',
					'path'  => 'import_validation_result.counts.diagnostics',
				) : null,
			)
		);

		$counts['provenance'] = $provenance;
		$counts['consistent'] = ( empty( $compiler_quality ) || empty( $report_quality ) || self::quality_metrics_agree( self::quality_metric_values( $compiler_quality, $keys ), $report_counts ) )
			&& ( empty( $validation_counts ) || ( empty( $compiler_quality ) || self::quality_metrics_agree( $validation_counts, self::quality_metric_values( $compiler_quality, $keys ) ) ) )
			&& ( empty( $report_quality ) || self::quality_metrics_agree( $validation_counts, $report_counts ) );

		return $counts;
	}

	/** @return array<string,mixed> */
	private static function import_validation_result( array $result, array $import_report ): array {
		foreach ( array( $result['import_validation_result'] ?? null, $import_report['import_validation_result'] ?? null ) as $candidate ) {
			if ( is_array( $candidate ) && isset( $candidate['counts'] ) && is_array( $candidate['counts'] ) ) {
				return $candidate;
			}
		}

		return array();
	}

	/** @return array<string,int> */
	private static function validation_quality_metric_values( array $validation ): array {
		$counts  = isset( $validation['counts'] ) && is_array( $validation['counts'] ) ? $validation['counts'] : array();
		$map     = array(
			'diagnostics'                        => 'diagnostic_count',
			'fallback_blocks'                    => 'fallback_count',
			'unsupported_fallbacks'              => 'unsupported_fallback_count',
			'accepted_preserved_runtime_islands' => 'accepted_preserved_runtime_island_count',
			'content_loss'                       => 'content_loss_count',
			'empty_conversions'                  => 'empty_conversion_count',
			'core_html_blocks'                   => 'core_html_block_count',
			'freeform_blocks'                    => 'freeform_block_count',
			'invalid_blocks'                     => 'invalid_block_count',
			'invalid_block_documents'            => 'invalid_block_document_count',
			'images_missing_source'              => 'image_missing_source_count',
			'unsafe_svgs'                        => 'unsafe_svg_count',
			'svg_materialization_failures'       => 'svg_materialization_failure_count',
			'svg_sprite_reference_failures'      => 'svg_sprite_reference_failure_count',
			'commerce_dependency_failures'       => 'commerce_dependency_failures',
			'interaction_candidates'             => 'interaction_candidate_count',
			'runtime_dependency_parity'          => 'runtime_dependency_parity_issue_count',
			'semantic_parity_failures'           => 'semantic_parity_failure_count',
			'unsafe_layout_constraints'          => 'unsafe_layout_constraint_count',
		);
		$metrics = array();
		foreach ( $map as $validation_key => $quality_key ) {
			if ( isset( $counts[ $validation_key ] ) && is_numeric( $counts[ $validation_key ] ) ) {
				$metrics[ $quality_key ] = max( 0, (int) $counts[ $validation_key ] );
			}
		}

		return $metrics;
	}

	/**
	 * Verify the public shape of #937 resolution evidence without repeating its
	 * materializer-level page and binding verification.
	 */
	private static function verified_provider_resolution_count( array $reconciliation ): ?int {
		if ( 'static-site-importer/quality-resolutions/v1' !== ( $reconciliation['schema'] ?? null ) || ! isset( $reconciliation['source_fallback_count'], $reconciliation['resolved_by_provider'], $reconciliation['unresolved_fallback_count'], $reconciliation['resolutions'] ) || ! is_numeric( $reconciliation['source_fallback_count'] ) || ! is_numeric( $reconciliation['resolved_by_provider'] ) || ! is_numeric( $reconciliation['unresolved_fallback_count'] ) || ! is_array( $reconciliation['resolutions'] ) ) {
			return null;
		}

		$source     = max( 0, (int) $reconciliation['source_fallback_count'] );
		$resolved   = max( 0, (int) $reconciliation['resolved_by_provider'] );
		$unresolved = max( 0, (int) $reconciliation['unresolved_fallback_count'] );
		if ( $source - $resolved !== $unresolved ) {
			return null;
		}

		$identities = array();
		foreach ( $reconciliation['resolutions'] as $resolution ) {
			if ( ! is_array( $resolution ) || 'resolved_by_provider' !== ( $resolution['state'] ?? null ) || ! is_string( $resolution['fallback_reconciliation_identity'] ?? null ) || ! is_string( $resolution['fallback_hash'] ?? null ) || 1 !== preg_match( '/^[a-f0-9]{64}$/', $resolution['fallback_reconciliation_identity'] ) || 1 !== preg_match( '/^[a-f0-9]{64}$/', $resolution['fallback_hash'] ) ) {
				return null;
			}
			$receipt = isset( $resolution['receipt'] ) && is_array( $resolution['receipt'] ) ? $resolution['receipt'] : array();
			if ( 'static-site-importer/quality-resolution-receipt/v1' !== ( $receipt['schema'] ?? null ) || 'completed' !== ( $receipt['status'] ?? null ) || ( $receipt['fallback_reconciliation_identity'] ?? null ) !== $resolution['fallback_reconciliation_identity'] || ( $receipt['fallback_hash'] ?? null ) !== $resolution['fallback_hash'] ) {
				return null;
			}
			foreach ( array( 'binding_reconciliation_identity', 'materialized_block_hash', 'materialized_content_hash' ) as $field ) {
				if ( ! is_string( $receipt[ $field ] ?? null ) || 1 !== preg_match( '/^[a-f0-9]{64}$/', $receipt[ $field ] ) ) {
					return null;
				}
			}
			if ( isset( $identities[ $resolution['fallback_reconciliation_identity'] ] ) ) {
				return null;
			}
			$identities[ $resolution['fallback_reconciliation_identity'] ] = true;
		}

		return count( $identities ) === $resolved ? $resolved : null;
	}

	/** @return array<string,int> */
	private static function quality_metric_values( array $quality, array $keys ): array {
		$metrics = isset( $quality['metrics'] ) && is_array( $quality['metrics'] ) ? $quality['metrics'] : $quality;
		$counts  = array();
		foreach ( $keys as $key ) {
			if ( isset( $metrics[ $key ] ) && is_numeric( $metrics[ $key ] ) ) {
				$counts[ $key ] = max( 0, (int) $metrics[ $key ] );
			}
		}
		return $counts;
	}

	private static function quality_metrics_agree( array $left, array $right ): bool {
		foreach ( $left as $key => $value ) {
			if ( isset( $right[ $key ] ) && $value !== $right[ $key ] ) {
				return false;
			}
		}
		return true;
	}

	/** @return array<int,array<string,mixed>> */
	private static function quality_count_consistency_diagnostics( array $quality_counts ): array {
		if ( ! empty( $quality_counts['consistent'] ) ) {
			return array();
		}
		return array(
			array(
				'type'        => 'quality_count_consistency_failure',
				'severity'    => 'error',
				'code'        => 'static_site_importer_quality_count_consistency_failure',
				'stage'       => 'quality_reconciliation',
				'owner'       => 'static-site-importer',
				'message'     => 'Canonical compiler quality counts disagree with the importer report; unresolved counts retain compiler evidence.',
				'constraints' => 'gating',
			),
		);
	}

	/**
	 * Derive bounded composition counts when a report carries documents but no aggregate.
	 *
	 * @param array<string,mixed> $import_report Import report.
	 * @return array<string,int>
	 */
	private static function block_document_quality_counts( array $import_report ): array {
		$materialized = isset( $import_report['materialized_content']['block_documents'] ) && is_array( $import_report['materialized_content']['block_documents'] )
			? $import_report['materialized_content']['block_documents']
			: array();
		$documents    = ! empty( $materialized )
			? $materialized
			: ( isset( $import_report['generated_theme']['block_documents'] ) && is_array( $import_report['generated_theme']['block_documents'] ) ? $import_report['generated_theme']['block_documents'] : array() );
		$counts       = array(
			'block_count'           => 0,
			'core_html_block_count' => 0,
			'freeform_block_count'  => 0,
		);

		foreach ( $documents as $document ) {
			if ( ! is_array( $document ) ) {
				continue;
			}
			$document_count = isset( $document['block_count'] ) && is_numeric( $document['block_count'] ) ? (int) $document['block_count'] : 0;
			if ( $document_count > 0 ) {
				$counts['block_count']           += $document_count;
				$counts['core_html_block_count'] += isset( $document['core_html_block_count'] ) && is_numeric( $document['core_html_block_count'] ) ? (int) $document['core_html_block_count'] : 0;
				$counts['freeform_block_count']  += isset( $document['freeform_block_count'] ) && is_numeric( $document['freeform_block_count'] ) ? (int) $document['freeform_block_count'] : 0;
				continue;
			}

			foreach ( array( 'content', 'post_content', 'block_markup', 'serialized_blocks' ) as $field ) {
				if ( isset( $document[ $field ] ) && is_string( $document[ $field ] ) && '' !== trim( $document[ $field ] ) ) {
					$parsed = self::serialized_block_quality_counts( $document[ $field ] );
					foreach ( $counts as $key => $value ) {
						$counts[ $key ] = $value + $parsed[ $key ];
					}
					break;
				}
			}
		}

		return $counts;
	}

	/**
	 * Count named Gutenberg block comments without retaining serialized content.
	 *
	 * @param string $content Serialized block document.
	 * @return array<string,int>
	 */
	private static function serialized_block_quality_counts( string $content ): array {
		$counts = array(
			'block_count'           => 0,
			'core_html_block_count' => 0,
			'freeform_block_count'  => 0,
		);
		if ( ! preg_match_all( '/<!--\s+wp:([a-z][a-z0-9-]*(?:\/[a-z][a-z0-9-]*)?)/i', $content, $matches ) ) {
			return $counts;
		}

		foreach ( $matches[1] as $name ) {
			$normalized = strtolower( (string) $name );
			++$counts['block_count'];
			if ( 'html' === $normalized || 'core/html' === $normalized ) {
				++$counts['core_html_block_count'];
			} elseif ( 'freeform' === $normalized || 'core/freeform' === $normalized ) {
				++$counts['freeform_block_count'];
			}
		}

		return $counts;
	}

	/**
	 * Summarize Blocks Engine import-report details.
	 *
	 * @param array<string,mixed> $import_report Import report.
	 * @return array<string,mixed>
	 */
	private static function blocks_engine_summary( array $import_report ): array {
		$blocks_engine = isset( $import_report['blocks_engine'] ) && is_array( $import_report['blocks_engine'] ) ? $import_report['blocks_engine'] : array();

		$summary = array();
		foreach ( array( 'transformer', 'website_artifact', 'conversion_report', 'runtime_dependency_parity', 'semantic_parity' ) as $field ) {
			if ( isset( $blocks_engine[ $field ] ) && is_array( $blocks_engine[ $field ] ) && ! empty( $blocks_engine[ $field ] ) ) {
				$summary[ $field ] = $blocks_engine[ $field ];
			}
		}
		$plan = isset( $blocks_engine['wordpress_site_plan'] ) && is_array( $blocks_engine['wordpress_site_plan'] ) ? $blocks_engine['wordpress_site_plan'] : array();
		if ( ! empty( $plan ) ) {
			$assets                         = isset( $plan['assets'] ) && is_array( $plan['assets'] ) ? $plan['assets'] : array();
			$summary['wordpress_site_plan'] = array(
				'schema'      => isset( $plan['schema'] ) && is_scalar( $plan['schema'] ) ? (string) $plan['schema'] : '',
				'asset_count' => count( $assets ),
				'assets'      => array_map( array( self::class, 'plan_asset_summary' ), array_slice( $assets, 0, 50 ) ),
			);
		}

		return $summary;
	}

	/**
	 * Retain immutable materialization evidence without duplicating the full site plan.
	 *
	 * @param array<string,mixed> $result        Provider result.
	 * @param array<string,mixed> $import_report Import report.
	 * @return array<string,mixed>
	 */
	private static function materialization_receipt_summary( array $result, array $import_report ): array {
		$receipt = array();
		foreach ( array( $result['materialization_receipt'] ?? null, $import_report['materialization_receipt'] ?? null ) as $candidate ) {
			if ( is_array( $candidate ) && ! empty( $candidate ) ) {
				$receipt = $candidate;
				break;
			}
		}
		if ( empty( $receipt ) ) {
			return array();
		}

		$completed = isset( $receipt['completed'] ) && is_array( $receipt['completed'] ) ? $receipt['completed'] : array();

		return array(
			'schema'                     => isset( $receipt['schema'] ) && is_scalar( $receipt['schema'] ) ? (string) $receipt['schema'] : '',
			'status'                     => isset( $receipt['status'] ) && is_scalar( $receipt['status'] ) ? (string) $receipt['status'] : '',
			'plan_identity'              => isset( $receipt['plan_identity'] ) && is_array( $receipt['plan_identity'] ) ? $receipt['plan_identity'] : array(),
			'page_count'                 => isset( $completed['pages'] ) && is_array( $completed['pages'] ) ? count( $completed['pages'] ) : 0,
			'file_count'                 => isset( $completed['files'] ) && is_array( $completed['files'] ) ? count( $completed['files'] ) : 0,
			'operation_count'            => isset( $completed['operations'] ) && is_array( $completed['operations'] ) ? count( $completed['operations'] ) : 0,
			'declaration_count'          => isset( $completed['declaration_ids'] ) && is_array( $completed['declaration_ids'] ) ? count( $completed['declaration_ids'] ) : 0,
			'block_provenance'           => self::block_provenance_summary( isset( $completed['block_provenance'] ) && is_array( $completed['block_provenance'] ) ? $completed['block_provenance'] : array() ),
			'block_provenance_count'     => isset( $completed['block_provenance_count'] ) ? (int) $completed['block_provenance_count'] : 0,
			'block_provenance_truncated' => ! empty( $completed['block_provenance_truncated'] ),
		);
	}

	/**
	 * Project provider-supplied provenance to immutable attribution metadata.
	 *
	 * @param array<int|string,mixed> $provenance Provider receipt provenance.
	 * @return array<int,array<string,mixed>>
	 */
	private static function block_provenance_summary( array $provenance ): array {
		$summary = array();
		foreach ( array_slice( array_values( $provenance ), 0, self::BLOCK_PROVENANCE_LIMIT ) as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$source = isset( $row['source'] ) && is_array( $row['source'] ) ? $row['source'] : array();
			$entry  = array(
				'source' => self::provenance_source_summary( $source ),
				'stages' => self::provenance_stage_summary( isset( $row['stages'] ) && is_array( $row['stages'] ) ? $row['stages'] : array() ),
			);
			if ( ! empty( $entry['source'] ) || ! empty( $entry['stages'] ) ) {
				$summary[] = $entry;
			}
		}

		return $summary;
	}

	/** @param array<string,mixed> $source @return array<string,string> */
	private static function provenance_source_summary( array $source ): array {
		$summary = array();
		foreach ( array( 'schema', 'source_path', 'reconciliation_identity' ) as $field ) {
			$value = isset( $source[ $field ] ) ? self::bounded_provenance_string( $source[ $field ], 1024 ) : '';
			if ( '' !== $value ) {
				$summary[ $field ] = $value;
			}
		}

		return $summary;
	}

	/** @param array<int|string,mixed> $stages @return array<int,array<string,mixed>> */
	private static function provenance_stage_summary( array $stages ): array {
		$summary = array();
		foreach ( array_slice( array_values( $stages ), 0, self::BLOCK_PROVENANCE_STAGE_LIMIT ) as $stage ) {
			if ( ! is_array( $stage ) ) {
				continue;
			}

			$entry = array();
			$name  = isset( $stage['stage'] ) ? self::bounded_provenance_string( $stage['stage'], 1024 ) : '';
			if ( '' !== $name ) {
				$entry['stage'] = $name;
			}
			foreach ( array( 'input_sha256', 'input_bytes', 'input_count' ) as $field ) {
				if ( isset( $stage[ $field ] ) && is_scalar( $stage[ $field ] ) ) {
					$value = 'input_sha256' === $field ? self::bounded_provenance_string( $stage[ $field ], 128 ) : (int) $stage[ $field ];
					if ( '' !== $value ) {
						$entry[ $field ] = $value;
					}
				}
			}
			$output         = isset( $stage['output'] ) && is_array( $stage['output'] ) ? $stage['output'] : array();
			$output_summary = array();
			foreach ( array( 'sha256', 'bytes', 'count' ) as $field ) {
				if ( isset( $output[ $field ] ) && is_scalar( $output[ $field ] ) ) {
					$value = 'sha256' === $field ? self::bounded_provenance_string( $output[ $field ], 128 ) : (int) $output[ $field ];
					if ( '' !== $value ) {
						$output_summary[ $field ] = $value;
					}
				}
			}
			if ( ! empty( $output_summary ) ) {
				$entry['output'] = $output_summary;
			}
			if ( ! empty( $entry ) ) {
				$summary[] = $entry;
			}
		}

		return $summary;
	}

	/** @param mixed $value */
	private static function bounded_provenance_string( $value, int $limit ): string {
		if ( ! is_scalar( $value ) ) {
			return '';
		}

		$value = substr( (string) $value, 0, $limit );

		return str_contains( $value, '<' ) || str_contains( $value, '>' ) ? '' : $value;
	}

	/**
	 * Bound a site-plan asset to fields needed for runtime attribution.
	 *
	 * @param mixed $asset Site-plan asset.
	 * @return array<string,mixed>
	 */
	private static function plan_asset_summary( $asset ): array {
		if ( ! is_array( $asset ) ) {
			return array();
		}

		$summary = array();
		foreach ( array( 'path', 'target_path', 'source', 'source_path', 'role', 'intent', 'kind', 'type', 'media_type', 'mime_type', 'placement', 'defer', 'async', 'payload_present', 'payload_sha256', 'payload_bytes', 'bytes', 'hash' ) as $field ) {
			if ( isset( $asset[ $field ] ) && is_scalar( $asset[ $field ] ) ) {
				$summary[ $field ] = $asset[ $field ];
			}
		}

		return $summary;
	}

	/**
	 * Build diagnostic counts by severity, category, type, owner, and bucket.
	 *
	 * @param array<int,array<string,mixed>> $diagnostics Diagnostics.
	 * @return array<string,mixed>
	 */
	private static function diagnostic_summary( array $diagnostics ): array {
		$summary = array(
			'total'         => count( $diagnostics ),
			'severity'      => array(),
			'category'      => array(),
			'loss_class'    => Static_Site_Importer_Diagnostic_Loss_Classes::counts( $diagnostics ),
			'type'          => array(),
			'parser_owner'  => array(),
			'repair_bucket' => array(),
		);
		foreach ( $diagnostics as $diagnostic ) {
			foreach ( array( 'severity', 'category', 'type', 'parser_owner', 'repair_bucket' ) as $field ) {
				$value                       = isset( $diagnostic[ $field ] ) && is_scalar( $diagnostic[ $field ] ) ? (string) $diagnostic[ $field ] : 'unknown';
				$summary[ $field ][ $value ] = ( $summary[ $field ][ $value ] ?? 0 ) + 1;
			}
		}

		return $summary;
	}

	/**
	 * Group diagnostics by a field.
	 *
	 * @param array<int,array<string,mixed>> $diagnostics Diagnostics.
	 * @param string                         $field       Field name.
	 * @return array<string,array<int,array<string,mixed>>>
	 */
	private static function diagnostics_by_field( array $diagnostics, string $field ): array {
		$grouped = array();
		foreach ( $diagnostics as $diagnostic ) {
			$key               = isset( $diagnostic[ $field ] ) && is_scalar( $diagnostic[ $field ] ) ? (string) $diagnostic[ $field ] : 'uncategorized';
			$grouped[ $key ][] = $diagnostic;
		}

		return $grouped;
	}

	/**
	 * Select diagnostics matching types or type fragments.
	 *
	 * @param array<int,array<string,mixed>> $diagnostics Diagnostics.
	 * @param array<int,string>              $needles     Type needles.
	 * @return array<int,array<string,mixed>>
	 */
	private static function diagnostics_matching_types( array $diagnostics, array $needles ): array {
		return array_values(
			array_filter(
				$diagnostics,
				static function ( array $diagnostic ) use ( $needles ): bool {
					$type     = isset( $diagnostic['type'] ) && is_scalar( $diagnostic['type'] ) ? (string) $diagnostic['type'] : '';
					$category = isset( $diagnostic['category'] ) && is_scalar( $diagnostic['category'] ) ? (string) $diagnostic['category'] : '';
					$bucket   = isset( $diagnostic['repair_bucket'] ) && is_scalar( $diagnostic['repair_bucket'] ) ? (string) $diagnostic['repair_bucket'] : '';
					foreach ( $needles as $needle ) {
						if ( $needle === $type || str_contains( $type, $needle ) || str_contains( $category, $needle ) || str_contains( $bucket, $needle ) ) {
							return true;
						}
					}

					return false;
				}
			)
		);
	}

	/**
	 * Build the top parser-owner/repair-bucket counts.
	 *
	 * @param array<int,array<string,mixed>> $diagnostics Diagnostics.
	 * @return array<int,array<string,mixed>>
	 */
	private static function top_parser_buckets( array $diagnostics ): array {
		$buckets = array();
		foreach ( $diagnostics as $diagnostic ) {
			$parser_owner  = isset( $diagnostic['parser_owner'] ) && is_scalar( $diagnostic['parser_owner'] ) ? (string) $diagnostic['parser_owner'] : 'static-site-importer';
			$repair_bucket = isset( $diagnostic['repair_bucket'] ) && is_scalar( $diagnostic['repair_bucket'] ) ? (string) $diagnostic['repair_bucket'] : 'static_site_import_quality';
			$key           = $parser_owner . ':' . $repair_bucket;
			if ( ! isset( $buckets[ $key ] ) ) {
				$buckets[ $key ] = array(
					'parser_owner'  => $parser_owner,
					'repair_bucket' => $repair_bucket,
					'count'         => 0,
				);
			}

			++$buckets[ $key ]['count'];
		}

		$values = array_values( $buckets );
		usort(
			$values,
			static function ( array $left, array $right ): int {
				$count_compare = $right['count'] <=> $left['count'];
				if ( 0 !== $count_compare ) {
					return $count_compare;
				}

				$owner_compare = strcmp( (string) $left['parser_owner'], (string) $right['parser_owner'] );
				if ( 0 !== $owner_compare ) {
					return $owner_compare;
				}

				return strcmp( (string) $left['repair_bucket'], (string) $right['repair_bucket'] );
			}
		);

		return $values;
	}

	/**
	 * Stable artifact references from validation/import output.
	 *
	 * @param array<string,mixed> $artifacts     Validation artifacts.
	 * @param array<string,mixed> $import_report Import report.
	 * @return array<string,mixed>
	 */
	private static function artifact_refs( array $artifacts, array $import_report ): array {
		$refs = self::sanitize_artifact_refs( $artifacts );
		if ( isset( $import_report['import_validation_result']['artifacts'] ) && is_array( $import_report['import_validation_result']['artifacts'] ) ) {
			$refs['import_validation_artifacts'] = self::sanitize_artifact_refs( $import_report['import_validation_result']['artifacts'] );
		}
		if ( isset( $import_report['visual_parity_artifacts'] ) && is_array( $import_report['visual_parity_artifacts'] ) ) {
			$refs['visual_parity_artifacts'] = self::sanitize_artifact_refs( $import_report['visual_parity_artifacts'] );
		}

		return $refs;
	}

	/**
	 * Remove local-only filesystem paths from reviewer-facing artifact refs.
	 *
	 * @param array<string,mixed> $refs Artifact refs.
	 * @return array<string,mixed>
	 */
	private static function sanitize_artifact_refs( array $refs ): array {
		$sanitized = array();
		foreach ( $refs as $key => $value ) {
			if ( in_array( $key, array( 'path', 'full_path', 'local_path' ), true ) ) {
				continue;
			}

			$sanitized[ $key ] = is_array( $value ) ? self::sanitize_artifact_refs( $value ) : $value;
		}

		return $sanitized;
	}

	/**
	 * Remove duplicate diagnostics by stable source context and reason.
	 *
	 * @param array<int,array<string,mixed>> $diagnostics Diagnostics.
	 * @return array<int,array<string,mixed>>
	 */
	private static function dedupe_diagnostics( array $diagnostics ): array {
		$seen   = array();
		$unique = array();
		foreach ( $diagnostics as $diagnostic ) {
			$key = self::diagnostic_dedupe_key( $diagnostic );
			if ( isset( $seen[ $key ] ) ) {
				$unique[ $seen[ $key ] ] = self::merge_diagnostic_context( $unique[ $seen[ $key ] ], $diagnostic );
				continue;
			}

			$seen[ $key ] = count( $unique );
			$unique[]     = $diagnostic;
		}

		return $unique;
	}

	/**
	 * Build a dedupe key that can collapse SSI and Blocks Engine echoes of the same finding.
	 *
	 * @param array<string,mixed> $diagnostic Diagnostic row.
	 * @return string
	 */
	private static function diagnostic_dedupe_key( array $diagnostic ): string {
		$source_path = isset( $diagnostic['source_path'] ) && is_scalar( $diagnostic['source_path'] ) ? (string) $diagnostic['source_path'] : '';
		$selector    = isset( $diagnostic['selector'] ) && is_scalar( $diagnostic['selector'] ) ? (string) $diagnostic['selector'] : '';
		$reason      = self::first_scalar( $diagnostic, array( 'reason_code', 'code', 'reason' ), '' );
		$loss_class  = isset( $diagnostic['loss_class'] ) && is_scalar( $diagnostic['loss_class'] ) ? (string) $diagnostic['loss_class'] : '';

		if ( '' !== $source_path && '' !== $selector && '' !== $reason ) {
			return implode( '|', array( 'context', $source_path, $selector, sanitize_key( $reason ), $loss_class ) );
		}

		return implode( '|', array_map( 'strval', array( 'identity', $diagnostic['id'] ?? '', $diagnostic['type'] ?? '', $source_path, $selector, $diagnostic['code'] ?? '' ) ) );
	}

	/**
	 * Merge duplicate diagnostics without discarding source evidence from either producer.
	 *
	 * @param array<string,mixed> $primary   First diagnostic row.
	 * @param array<string,mixed> $duplicate Duplicate diagnostic row.
	 * @return array<string,mixed>
	 */
	private static function merge_diagnostic_context( array $primary, array $duplicate ): array {
		foreach ( $duplicate as $field => $value ) {
			if ( ! array_key_exists( $field, $primary ) || '' === $primary[ $field ] || null === $primary[ $field ] || array() === $primary[ $field ] ) {
				$primary[ $field ] = $value;
			}
		}

		return $primary;
	}

	/**
	 * Resolve a scalar value from candidate fields.
	 *
	 * @param array<string,mixed> $row      Source row.
	 * @param array<int,string>   $fields   Candidate fields.
	 * @param string              $fallback Fallback value.
	 * @return string
	 */
	private static function first_scalar( array $row, array $fields, string $fallback = '' ): string {
		foreach ( $fields as $field ) {
			if ( isset( $row[ $field ] ) && is_scalar( $row[ $field ] ) && '' !== trim( (string) $row[ $field ] ) ) {
				return (string) $row[ $field ];
			}
		}

		return $fallback;
	}

	/**
	 * Resolve a diagnostic identity value without treating counts/indexes as codes.
	 *
	 * @param array<string,mixed> $row      Source row.
	 * @param array<int,string>   $fields   Candidate fields.
	 * @param string              $fallback Fallback value.
	 * @return string
	 */
	private static function first_identifier( array $row, array $fields, string $fallback = '' ): string {
		foreach ( $fields as $field ) {
			if ( ! isset( $row[ $field ] ) || ! is_scalar( $row[ $field ] ) ) {
				continue;
			}

			$value = trim( (string) $row[ $field ] );
			if ( '' === $value || self::is_numeric_only_string( $value ) ) {
				continue;
			}

			return $value;
		}

		return $fallback;
	}

	/**
	 * Check whether a string is only a numeric count/index.
	 *
	 * @param string $value Value.
	 * @return bool
	 */
	private static function is_numeric_only_string( string $value ): bool {
		return 1 === preg_match( '/^\d+$/', trim( $value ) );
	}

	/**
	 * Check whether a diagnostic row is report evidence rather than repair work.
	 *
	 * @param array<string,mixed> $row Source row.
	 * @return bool
	 */
	private static function is_report_only_diagnostic( array $row ): bool {
		$constraints = strtolower( self::first_scalar( $row, array( 'constraints', 'constraint' ), '' ) );

		return in_array( $constraints, array( 'report_only', 'report-only' ), true );
	}

	/**
	 * Check whether a diagnostic is only a count/index placeholder.
	 *
	 * @param array<string,mixed> $row Source row.
	 * @return bool
	 */
	private static function is_count_only_diagnostic( array $row ): bool {
		$type   = sanitize_key( self::first_scalar( $row, array( 'type', 'kind', 'code' ), '' ) );
		$reason = self::first_scalar( $row, array( 'reason_code', 'reason', 'error_code', 'message' ), '' );

		if ( ! self::is_placeholder_scalar( $type ) && ! in_array( $type, array( 'diagnostic', 'import_diagnostic', 'static_site_fixture_diagnostic', 'static_site_importer_diagnostic' ), true ) ) {
			return false;
		}

		if ( '' !== $reason && ! self::is_placeholder_scalar( $reason ) ) {
			return false;
		}

		foreach ( array( 'selector', 'source_snippet', 'source_html_preview', 'emitted_block_preview', 'observed_output', 'html_excerpt', 'excerpt', 'script_path', 'src', 'href', 'expected', 'observed' ) as $field ) {
			if ( isset( $row[ $field ] ) && is_scalar( $row[ $field ] ) && ! self::is_placeholder_scalar( (string) $row[ $field ] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Check whether a scalar is a placeholder rather than source evidence.
	 *
	 * @param string $value Value.
	 * @return bool
	 */
	private static function is_placeholder_scalar( string $value ): bool {
		$value = trim( strtolower( $value ) );

		return '' === $value || '(none)' === $value || 'none' === $value || self::is_numeric_only_string( $value );
	}

	/**
	 * Classify diagnostics by generic category.
	 *
	 * @param string $type Diagnostic type.
	 * @return string
	 */
	private static function diagnostic_category( string $type ): string {
		if ( str_contains( $type, 'svg' ) ) {
			return 'svg';
		}
		if ( str_contains( $type, 'asset' ) || str_contains( $type, 'image' ) ) {
			return 'asset';
		}
		if ( str_contains( $type, 'runtime_dependency' ) || str_contains( $type, 'dom_target' ) || str_contains( $type, 'runtime_target' ) ) {
			return 'runtime_dependency_parity';
		}
		if ( str_contains( $type, 'semantic_parity' ) || str_contains( $type, 'navigation_' ) || str_contains( $type, 'landmark_' ) ) {
			return 'semantic_parity';
		}
		if ( str_contains( $type, 'core_html' ) || str_contains( $type, 'freeform' ) || str_contains( $type, 'fallback' ) ) {
			return 'fallback_block';
		}
		if ( str_contains( $type, 'invalid_block' ) || str_contains( $type, 'block_validation' ) ) {
			return 'block_validity';
		}
		if ( str_contains( $type, 'button' ) || str_contains( $type, 'style' ) || str_contains( $type, 'presentation' ) ) {
			return 'style_loss_hint';
		}

		return 'import_quality';
	}

	/**
	 * Determine repair bucket.
	 *
	 * @param string              $type        Diagnostic type.
	 * @param string              $reason_code Reason code.
	 * @param array<string,mixed> $row         Source row.
	 * @return string
	 */
	private static function repair_bucket( string $type, string $reason_code, array $row ): string {
		$explicit = self::first_scalar( $row, array( 'repair_bucket', 'group_key' ), '' );
		if ( '' !== $explicit ) {
			return sanitize_key( $explicit );
		}
		if ( 'document_metadata_routed' === $type ) {
			return 'static_site_import_quality';
		}

		$haystack = strtolower( implode( ' ', array( $type, $reason_code, self::first_scalar( $row, array( 'message', 'reason', 'detail' ), '' ) ) ) );
		if ( str_contains( $haystack, 'runtime_dependency' ) || str_contains( $haystack, 'dom_target' ) || str_contains( $haystack, 'runtime_target' ) || str_contains( $haystack, 'canvas' ) || str_contains( $haystack, 'animation' ) ) {
			return 'runtime_target_gap';
		}
		if ( str_contains( $haystack, 'invalid_block' ) || str_contains( $haystack, 'block_validation' ) || str_contains( $haystack, 'invalid content' ) ) {
			return 'invalid_block_content';
		}
		if ( str_contains( $haystack, 'svg' ) ) {
			return 'broken_svg';
		}
		if ( str_contains( $haystack, 'asset' ) || str_contains( $haystack, 'image' ) || self::missing_asset_path( $row ) ) {
			return 'dropped_images';
		}
		if ( str_contains( $haystack, 'button' ) || str_contains( $haystack, 'style' ) || str_contains( $haystack, 'presentation' ) ) {
			return 'button_style_loss';
		}
		if ( str_contains( $haystack, 'semantic_parity' ) || str_contains( $haystack, 'navigation_' ) || str_contains( $haystack, 'landmark_' ) ) {
			return 'semantic_parity';
		}
		if ( str_contains( $haystack, 'core_html' ) || str_contains( $haystack, 'freeform' ) || str_contains( $haystack, 'fallback' ) ) {
			return 'fallback_block';
		}

		return 'static_site_import_quality';
	}

	/**
	 * Keep acceptable runtime islands out of actionable importer-quality buckets.
	 *
	 * @param string $repair_bucket Current repair bucket.
	 * @param string $loss_class    Product-facing loss class.
	 * @return string
	 */
	private static function repair_bucket_for_loss_class( string $repair_bucket, string $loss_class ): string {
		if ( Static_Site_Importer_Diagnostic_Loss_Classes::PRESERVED_RUNTIME_ISLAND !== $loss_class ) {
			return $repair_bucket;
		}

		return in_array( $repair_bucket, array( 'static_site_import_quality', 'import_quality' ), true ) ? Static_Site_Importer_Diagnostic_Loss_Classes::PRESERVED_RUNTIME_ISLAND : $repair_bucket;
	}

	/**
	 * Determine likely product owner for the parser/repair bucket.
	 *
	 * @param string              $type          Diagnostic type.
	 * @param string              $repair_bucket Repair bucket.
	 * @param array<string,mixed> $row           Source row.
	 * @return string
	 */
	private static function parser_owner( string $type, string $repair_bucket, array $row ): string {
		$explicit = self::first_scalar( $row, array( 'parser_owner', 'owner' ), '' );
		if ( in_array( $explicit, array( 'blocks-engine', 'static-site-importer' ), true ) ) {
			return $explicit;
		}

		$engine = self::first_scalar( $row, array( 'engine', 'converter', 'candidate_repo' ), '' );
		if ( str_contains( $engine, 'blocks-engine' ) ) {
			return 'blocks-engine';
		}
		if ( str_contains( $engine, 'static-site-importer' ) ) {
			return 'static-site-importer';
		}

		if ( in_array( $repair_bucket, array( 'dropped_images', 'static_site_import_quality' ), true ) || str_contains( $type, 'asset' ) || str_contains( $type, 'image' ) ) {
			return 'static-site-importer';
		}

		return 'blocks-engine';
	}

	/**
	 * Repair mode for a bucket.
	 *
	 * @param string $repair_bucket Repair bucket.
	 * @return string
	 */
	private static function repair_mode( string $repair_bucket ): string {
		$modes = array(
			'button_style_loss'          => 'transformer-style-parity',
			'broken_svg'                 => 'svg-transformer-parity',
			'dropped_images'             => 'asset-materialization',
			'invalid_block_content'      => 'block-validation-parity',
			'preserved_runtime_island'   => 'accepted-runtime-preservation',
			'runtime_target_gap'         => 'runtime-dom-target-parity',
			'semantic_parity'            => 'semantic-parity',
			'fallback_block'             => 'fallback-block-replacement',
			'static_site_import_quality' => 'import-validation',
		);

		return $modes[ $repair_bucket ] ?? 'import-validation';
	}

	/**
	 * Classify whether a diagnostic represents acceptable preservation or an imported-output defect.
	 *
	 * @param string $loss_class Normalized loss class.
	 * @return string
	 */
	private static function diagnostic_acceptability( string $loss_class ): string {
		if ( Static_Site_Importer_Diagnostic_Loss_Classes::PRESERVED_RUNTIME_ISLAND === $loss_class ) {
			return 'acceptable_preservation';
		}
		if ( in_array( $loss_class, array( Static_Site_Importer_Diagnostic_Loss_Classes::NATIVE_CONVERSION, Static_Site_Importer_Diagnostic_Loss_Classes::EDITABLE_APPROXIMATION ), true ) ) {
			return 'acceptable_conversion';
		}

		return 'unacceptable_imported_output_defect';
	}

	/**
	 * Preserve exact source diagnostic identity for matrix and repair-loop consumers.
	 *
	 * @param array<string,mixed> $row        Raw diagnostic row.
	 * @param array<string,mixed> $diagnostic Normalized diagnostic row.
	 * @return array<string,string>
	 */
	private static function source_diagnostic_identity( array $row, array $diagnostic ): array {
		$identity = array();
		foreach ( array( 'id', 'type', 'kind', 'code', 'reason_code', 'reason', 'message', 'source_path', 'selector', 'stage', 'engine' ) as $field ) {
			$value = self::first_scalar( $row, array( $field ), '' );
			if ( '' === $value ) {
				$value = self::first_scalar( $diagnostic, array( $field ), '' );
			}
			if ( '' !== $value ) {
				$identity[ $field ] = $value;
			}
		}

		return $identity;
	}

	/**
	 * Default diagnostic severity.
	 *
	 * @param string $type Diagnostic type.
	 * @return string
	 */
	private static function default_diagnostic_severity( string $type ): string {
		return str_contains( $type, 'missing' ) || str_contains( $type, 'invalid' ) || str_contains( $type, 'error' ) ? 'error' : 'warning';
	}

	/**
	 * Extract a missing asset path.
	 *
	 * @param array<string,mixed> $row Diagnostic row.
	 * @return string
	 */
	private static function missing_asset_path( array $row ): string {
		return self::first_scalar( $row, array( 'missing_asset_path', 'asset_path', 'src', 'href' ), '' );
	}
}
